#!/usr/bin/env python3
"""V.A. History Continuity Kernel v1 — pre-consequence lineage gate.

Five exact invariants, one gate. This checks custody and standing continuity;
it does not establish the truth of mathematical or physical claims.

The trusted contract hash and trusted history tip must be kept by the host,
outside caller-writable data. SHA-256 binds bytes; it is not an identity signature.
"""

from hashlib import sha256
import json


SCHEMA = "VA_NEWK_HISTORY_CONTINUITY_V1"
CONTRACT_SCHEMA = "VA_HISTORY_CONTRACT_V1"
EVIDENCE_SCHEMA = "VA_HISTORY_EVIDENCE_V1"
INVARIANTS = (
    "I1_identity", "I2_continuity", "I3_evidence_custody",
    "I4_evidence_consumption", "I5_conditions_unchanged",
)
REQUEST_KEYS = frozenset({
    "event_id", "sequence", "previous_receipt_sha256", "stream_id",
    "question", "source_sha256", "scope", "conditions",
    "consumed_evidence_ids",
})


def _check_exact(value):
    """Refuse floating tolerances or unserializable objects in custody inputs."""
    if value is None or type(value) in (str, bool, int):
        return
    if isinstance(value, list):
        for item in value:
            _check_exact(item)
        return
    if isinstance(value, dict) and all(type(k) is str for k in value):
        for item in value.values():
            _check_exact(item)
        return
    raise ValueError("Only exact JSON values are admitted; floating values refused")


def _digest(value):
    _check_exact(value)
    return sha256(json.dumps(value, sort_keys=True, ensure_ascii=True,
                             separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _stamped(value):
    if "sha256" in value:
        raise ValueError("Do not supply a claimed digest to the stamper")
    return {**value, "sha256": _digest(value)}


def _valid_stamp(value):
    return (isinstance(value, dict) and type(value.get("sha256")) is str
            and value["sha256"] == _digest({k: v for k, v in value.items()
                                                  if k != "sha256"}))


def make_evidence(identity, kind, scope, body):
    """Create a content-addressed evidence carrier without fitted weights."""
    if any(type(x) is not str or not x.strip() for x in (identity, kind, scope)):
        raise ValueError("Evidence identity, kind and scope must be named")
    _check_exact(body)
    return _stamped({"schema": EVIDENCE_SCHEMA, "id": identity, "kind": kind,
                     "scope": scope, "body": body})


def create_contract(*, stream_id, question, source_sha256, scope, evidence):
    """Freeze expected evidence identities and hashes before any decision."""
    if any(type(x) is not str or not x.strip()
           for x in (stream_id, question, source_sha256, scope)):
        raise ValueError("Missing history stream, question, source or scope")
    if not isinstance(evidence, list) or not evidence:
        raise ValueError("At least one exact evidence carrier is required")
    if not all(_valid_stamp(item) and item.get("schema") == EVIDENCE_SCHEMA
               and item.get("scope") == scope for item in evidence):
        raise ValueError("Contract cannot pin invalid or mismatched evidence")
    if len({item["id"] for item in evidence}) != len(evidence):
        raise ValueError("Duplicate evidence IDs are forbidden")
    return _stamped({"schema": CONTRACT_SCHEMA, "stream_id": stream_id,
                     "question": question, "source_sha256": source_sha256,
                     "scope": scope,
                     "required_evidence": sorted(({
                         "id": item["id"], "kind": item["kind"],
                         "scope": item["scope"], "sha256": item["sha256"]}
                         for item in evidence), key=lambda x: x["id"])})


def _continuity(contract, request, prior, trusted_tip_sha256):
    if type(request.get("sequence")) is not int or request["sequence"] < 0:
        return False
    if prior is None:
        return (request["sequence"] == 0
                and request["previous_receipt_sha256"] is None
                and trusted_tip_sha256 is None)
    return (trusted_tip_sha256 is not None and _valid_stamp(prior)
            and prior.get("schema") == SCHEMA
            and prior.get("gate") == "CARRY"
            and prior.get("contract_sha256") == contract["sha256"]
            and request["sequence"] == prior["request"]["sequence"] + 1
            and request["previous_receipt_sha256"] == prior["sha256"]
            and trusted_tip_sha256 == prior["sha256"])


def evaluate(contract, evidence, request, *, prior=None, trusted_tip_sha256=None,
             trusted_contract_sha256=None, consumption_verifier=None):
    """One pre-formation gate: CARRY, REEXAMINE, or REFUSE.

    REFUSE prevents custody inheritance; REEXAMINE prevents unexamined
    inheritance across condition changes. Neither outcome performs an action.
    """
    if not isinstance(request, dict) or set(request) != REQUEST_KEYS:
        raise ValueError("History request must contain precisely the declared fields")
    _check_exact(request)
    if not isinstance(contract, dict) or not isinstance(evidence, list):
        raise ValueError("History contract and evidence types invalid")

    contract_valid = (_valid_stamp(contract)
                      and contract.get("schema") == CONTRACT_SCHEMA
                      and type(trusted_contract_sha256) is str
                      and contract["sha256"] == trusted_contract_sha256)
    anchors = contract.get("required_evidence", []) if contract_valid else []
    required = {a["id"]: a for a in anchors if isinstance(a, dict) and "id" in a}
    carriers = {x["id"]: x for x in evidence
                if isinstance(x, dict) and type(x.get("id")) is str}

    i1 = (contract_valid and type(request["event_id"]) is str
          and bool(request["event_id"].strip())
          and request["stream_id"] == contract["stream_id"]
          and request["question"] == contract["question"]
          and request["source_sha256"] == contract["source_sha256"])
    i2 = bool(contract_valid and _continuity(
        contract, request, prior, trusted_tip_sha256))
    i3 = (contract_valid and len(carriers) == len(evidence) == len(required)
          and set(carriers) == set(required)
          and all(_valid_stamp(carriers[k])
                  and carriers[k].get("schema") == EVIDENCE_SCHEMA
                  and carriers[k]["sha256"] == required[k]["sha256"]
                  and carriers[k]["kind"] == required[k]["kind"]
                  and carriers[k]["scope"] == required[k]["scope"]
                  for k in required))
    consumed = request["consumed_evidence_ids"]
    valid_consumed = (isinstance(consumed, list) and
                      all(type(x) is str for x in consumed) and
                      len(set(consumed)) == len(consumed))
    observed_used = []
    actual_consumption_verified = False
    if i3 and callable(consumption_verifier):
        try:
            result = consumption_verifier(evidence, request)
            actual_consumption_verified = (isinstance(result, dict)
                                           and result.get("verified") is True)
            used = result.get("used_evidence_ids", []) if isinstance(result, dict) else []
            if (isinstance(used, list) and all(type(x) is str for x in used)
                    and len(set(used)) == len(used)):
                observed_used = used
            else:
                actual_consumption_verified = False
        except (KeyError, ValueError, TypeError, ArithmeticError):
            actual_consumption_verified = False
    claimed = set(consumed) if valid_consumed else set()
    observed = set(observed_used)
    missing = sorted((set(required) - claimed) | (set(required) - observed))
    i4 = (bool(contract_valid) and valid_consumed
          and actual_consumption_verified and claimed == set(required)
          and observed == set(required)
          and request["scope"] == contract["scope"])
    current_condition = _digest(request["conditions"])
    i5 = (prior is None or (isinstance(prior, dict) and
                           current_condition == prior.get("conditions_sha256")))
    invariants = dict(zip(INVARIANTS, map(bool, (i1, i2, i3, i4, i5))))
    if not all(invariants[k] for k in INVARIANTS[:4]):
        gate = "REFUSE"
    elif not invariants[INVARIANTS[4]]:
        gate = "REEXAMINE"
    else:
        gate = "CARRY"
    return _stamped({
        "schema": SCHEMA,
        "contract_sha256": contract.get("sha256"),
        "request": request,
        "conditions_sha256": current_condition,
        "observed_evidence_sha256": {k: carriers[k].get("sha256") for k in sorted(carriers)},
        "observed_used_evidence_ids": sorted(observed_used),
        "consumption_replay_verified": actual_consumption_verified,
        "missing_consumed_evidence_ids": missing,
        "invariants": invariants,
        "gate": gate,
        "standing_inherited": gate == "CARRY",
        "mathematical_claim_verified_by_history": False,
        "host_must_enforce_before_consequence": True,
    })


def replay(receipt, *, contract, evidence, trusted_contract_sha256,
           prior=None, trusted_tip_sha256=None, consumption_verifier=None):
    """Recompute the gate, never trust a rehashed outcome label."""
    if (not _valid_stamp(receipt) or receipt.get("schema") != SCHEMA
            or contract.get("sha256") != trusted_contract_sha256):
        return False
    try:
        expected = evaluate(contract, evidence, receipt["request"], prior=prior,
                            trusted_tip_sha256=trusted_tip_sha256,
                            trusted_contract_sha256=trusted_contract_sha256,
                            consumption_verifier=consumption_verifier)
    except (KeyError, TypeError, ValueError):
        return False
    return expected == receipt
