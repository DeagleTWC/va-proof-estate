"""Executable process exit must never authorize a refused history event."""

import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from hodge_history_adapter import build_hodge_case


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "hodge_parent_v3_source_receipt.json"
PIN = "7966f67398ea83bbb8e4ec88e57f7307014148a0bbf8fdb37af7924f7e9d2d23"


class HistoryCliTests(unittest.TestCase):
    def test_hodge_example_generation_follows_frozen_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            case_path = Path(tmp) / "generated.json"
            result = subprocess.run([
                sys.executable, str(ROOT / "history_cli.py"), "hodge-example",
                "--source", str(SOURCE), "--expected-source-sha", PIN,
                "--output", str(case_path)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            case = json.loads(case_path.read_text(encoding="utf8"))
            self.assertEqual(case["request"]["consumed_evidence_ids"],
                             ["edge", "rational", "cycles"])
            self.assertEqual(case["consumption_verifier_id"], "HODGE_RANK_CLOSURE_V1")

    def test_good_and_missing_edge_have_distinct_executable_exit_codes(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            for omit_edge, expected_gate, expected_code in (
                    (False, "CARRY", 0), (True, "REFUSE", 3)):
                case = build_hodge_case(SOURCE, trusted_source_sha256=PIN,
                                        omit_edge=omit_edge)
                case_path = folder / ("omit.json" if omit_edge else "good.json")
                receipt_path = folder / ("omit-receipt.json" if omit_edge else "good-receipt.json")
                case_path.write_text(json.dumps(case), encoding="utf8")
                cmd = [sys.executable, str(ROOT / "history_cli.py"), "run",
                       "--case", str(case_path), "--output", str(receipt_path),
                       "--trusted-contract-sha", case["trusted_contract_sha256"]]
                result = subprocess.run(cmd, capture_output=True, text=True)
                self.assertEqual(result.returncode, expected_code, result.stderr)
                receipt = json.loads(receipt_path.read_text(encoding="utf8"))
                self.assertEqual(receipt["gate"], expected_gate)
                verify = subprocess.run([sys.executable, str(ROOT / "history_cli.py"),
                                         "replay", "--case", str(case_path),
                                         "--receipt", str(receipt_path),
                                         "--trusted-contract-sha", case["trusted_contract_sha256"]],
                                        capture_output=True, text=True)
                self.assertEqual(verify.returncode, 0, verify.stderr)
                self.assertIn("REPLAY_OK", verify.stdout)

    def test_run_cannot_use_contract_hash_from_same_editable_case_without_anchor(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = build_hodge_case(SOURCE, trusted_source_sha256=PIN)
            case_path = Path(tmp) / "case.json"
            case_path.write_text(json.dumps(case), encoding="utf8")
            result = subprocess.run([sys.executable, str(ROOT / "history_cli.py"), "run",
                                     "--case", str(case_path),
                                     "--output", str(Path(tmp) / "receipt.json")],
                                    capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)


if __name__ == "__main__":
    unittest.main()
