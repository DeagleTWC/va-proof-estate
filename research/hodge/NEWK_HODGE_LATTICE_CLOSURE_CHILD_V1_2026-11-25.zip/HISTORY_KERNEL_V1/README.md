# V.A. History Continuity Kernel v1 — Proof Before Power

**Research stewardship:** Terry Allen Snyder / DeagleTWC / V.A. Proof Estate  
**Executable public-safe child:** 25 November 2026  
**Status:** Reference child with a tested Hodge-v3 evidence adapter; **not** a claim of access to protected native GEN 1056.

## Question

Can this proposed consequence inherit standing from the verified history,
or do broken lineage, missing consumed evidence, or changed conditions
require refusal or re-examination **before any action occurs**?

## One kernel · five exact invariants · one gate

Let `E` be the required evidence IDs frozen in a trusted contract, `R` the
actual IDs read by a domain-specific source-replay rule, `C` the claimed
consumption IDs, `H` an exact canonical SHA-256 content digest, and `T` the
externally anchored prior receipt digest.

1. `I1_identity`: declared stream, question, source and contract match.
2. `I2_continuity`: sequence, prior receipt and **externally trusted tip** match.
3. `I3_evidence_custody`: every evidence record hashes to the frozen contract.
4. `I4_evidence_consumption`: a *registered verifier actually replays the
   source rule*, says `verified`, and its observed `R` equals `E` and `C`.
   A caller merely naming the edge is never enough.
5. `I5_conditions_unchanged`: exact current-condition identity equals the
   previous carried state; a changed condition requires new resolution.

The single gate is:

```text
REFUSE       if any of I1, I2, I3, I4 is false
REEXAMINE    if I1..I4 hold and I5 is false
CARRY        only if all five hold
```

The implementation uses exact JSON and hashes, not fitted numerical scores,
tolerances or trusted verdict labels. It performs **no action itself**. A host
must enforce the gate before any consequential operation; CLI exit status is
`0=CARRY`, `2=REEXAMINE`, `3=REFUSE`. A replayed refusal is still a valid
receipt, not permission to act.

## Actual Hodge source demonstration

The supplied frozen parent source is the public Hodge v3 exact Fermat-quintic
receipt (SHA-256 `7966f67398ea83bbb8e4ec88e57f7307014148a0bbf8fdb37af7924f7e9d2d23`).
The adapter binds its edge receipt and 10-basis source measurement, rational
Hodge dimension 401, reconstructed cycle rank 401, and source receipt IDs.

- Correct source/edge/rational/cycle chain → `CARRY` (history custody only).
- Same chain **omitting edge consumption** → `REFUSE`.
- Altered/rehashed edge, forked tip, scope lift, or missing verifier → `REFUSE`.
- Changed conditions → `REEXAMINE`.
- Both example receipts independently replay `REPLAY_OK`.

**Crucial limitation:** History `CARRY` means the supplied proof/evidence
lineage is intact under its registered verifier. It does **not** establish the
Hodge Conjecture or any new mathematical theorem. The adapter's rank check
verifies integer consistency; underlying geometry remains the Hodge parent's
responsibility. SHA-256 is tamper-evidence against anchored digests, **not**
identity authentication or proof that source content is true.

## Reproduce

From this directory:

```bash
python -m unittest discover -p 'test_*.py' -v

python history_cli.py hodge-example \
  --source hodge_parent_v3_source_receipt.json \
  --expected-source-sha 7966f67398ea83bbb8e4ec88e57f7307014148a0bbf8fdb37af7924f7e9d2d23 \
  --output hodge_history_case.json

python history_cli.py run --case hodge_history_case.json \
  --trusted-contract-sha 34a3c074268097fd075c4dd5dc2d21df0453dd037b20f969cc72b8fc20fbafa9 \
  --output hodge_history_carry_receipt.json

python history_cli.py replay --case hodge_history_case.json \
  --trusted-contract-sha 34a3c074268097fd075c4dd5dc2d21df0453dd037b20f969cc72b8fc20fbafa9 \
  --receipt hodge_history_carry_receipt.json
```

The trusted contract hash in a **production host must be obtained from
independent, protected custody**, not copied at runtime from the same
caller-editable case. Similarly, the next-event history tip must come from a
trusted store, not from the submitted request. The example's literals are a
public demonstration anchor, not a production security root.

## Applying this family-wide

One shared invariant contract, with a separate trusted source replay rule for
each type of evidence. See [INTEGRATION_ROLLOUT.md](INTEGRATION_ROLLOUT.md).
**Do not wire an unvalidated adapter into a live service or hardware system.**

## Identifier child kernel v1 — source geometry to custody records

The History Kernel now has a **separate executable identifier child**:
`identifier_kernel.py`, `hodge_identifier_adapter.py`, and `identifier_cli.py`.
It does not change the frozen Hodge v3 source or the original History v1
receipts. Its two linked identity levels are:

1. `VA:OBJECT:<full SHA-256>` for an exact geometric plane, computed from
   canonical rational row space where possible, or exact cyclotomic pairing
   descriptor with odd exponents of the primitive 10th root.
   `VA:CLASS:<full SHA-256>` separately names the symbolic class `H²`.
2. `VA:REC:<full SHA-256>` for the source-specific evidence record. A basis
   object and its independently generated instance may have the **same
   geometry ID but different record IDs**, as required.

There are also distinct `VA:SOURCE`, `VA:EDGE`, `VA:LEDGER`, and `VA:EVENT`
identities. All SHA-256 values are content-derived using canonical exact JSON,
domain-separated for the kind. These are *reproducible identifiers*, not
authentication credentials or assertions that mathematics has been proved.

### Exact observed coverage

- Original edge receipt lists **10 basis cycles**: 9 exact row-space planes
  and 1 symbolic `H²` class.
- Frozen `fermat_family_regenerator.py`, verified against source custody
  SHA-256 `79afac23476bd1849f56e5919ba4a9bd2469ca7235efcce41da5884d3d608f55`,
  yields **1,875 plane descriptors** by the explicit rule
  `15 perfect matchings × 5³ odd cyclotomic choices`.
- **1,875/1,875 plane identifiers** were derived and the entire ordered
  sequence was compared with the pinned generator output. No IDs came from
  the summary count alone.
- Nine original row-space planes coincide exactly with generated planes;
  their geometry IDs agree. There are **1,876 distinct class/object IDs**
  (the 1,875 planes plus symbolic `H²`) represented by **1,885 records**.
- A new **fourth History carrier** makes the identifier ledger an actual
  consumed source input. Omitting it, substituting a hand-entered event ID,
  tampering with the generator or rehashing an altered identity receipt
  causes refusal.

For the two-layer executable reproduction:

```bash
python -m unittest discover -p 'test_*.py' -q

python identifier_cli.py hodge \
  --source hodge_parent_v3_source_receipt.json \
  --expected-source-sha 7966f67398ea83bbb8e4ec88e57f7307014148a0bbf8fdb37af7924f7e9d2d23 \
  --output-prefix hodge_identified_v1

# Copy the independent trusted contract hash from your separately anchored
# custody record; in this public example its value is also in the case JSON.
python identifier_cli.py replay \
  --source hodge_parent_v3_source_receipt.json \
  --expected-source-sha 7966f67398ea83bbb8e4ec88e57f7307014148a0bbf8fdb37af7924f7e9d2d23 \
  --output-prefix hodge_identified_v1 \
  --trusted-contract-sha <TRUSTED_CONTRACT_SHA>
```

The pinned generator source is packaged **as a source-custody reference**;
the child implements its exact finite enumeration independently and compares
the generated list to the source algorithm's known SHA-256 fixture. This
bounded identifier issuance is not a proof of unrestricted Hodge, and is
not native GEN 1056 deployment.

## Exact New K Lattice Closure Child v1 — identifiers become relationships

This separate continuation adds `lattice_closure.py` and
`lattice_closure_cli.py` without changing any frozen earlier source, test,
case or receipt. See [the dated formal statement](NEWK_LATTICE_CLOSURE_FORMAL_2026-11-25.md).

It replays the original 1,875 object IDs, partitions the 1,875 planes into
**480 Galois orbits** (15 singletons, 465 quartets), and independently
rebuilds the source-selected 401×401 exact integer Gram matrix. The full
matrix is in the generated `*_exact_evidence.json`, not merely a verdict.
The determinant is **437 modulo 1009**, with full Gram SHA-256
`091350e197c318cf910b57c2153ea2de45d9f7cc9517c2f548a7e3fee01ad834`
matching a separately executed frozen parent generator.

The five invariants are source custody, geometry identity, Galois closure,
intersection witness, and rational cycle-span closure. **One gate:**
`CARRY` for complete identical conditions, `REEXAMINE` when conditions
change, and `REFUSE` for unsupported or corrupted source evidence.

Run inside this extracted folder:

```bash
python -m unittest discover -p 'test_*.py' -q

python lattice_closure_cli.py run --output-prefix newk_lattice_closure_v1 \
  --trusted-source-sha 7966f67398ea83bbb8e4ec88e57f7307014148a0bbf8fdb37af7924f7e9d2d23 \
  --trusted-ledger-sha 569b52d99fc7ad1a5b96effacdb864422b82d00fe3fece353a7e171553f3c22b

python lattice_closure_cli.py replay --output-prefix newk_lattice_closure_v1 \
  --trusted-source-sha 7966f67398ea83bbb8e4ec88e57f7307014148a0bbf8fdb37af7924f7e9d2d23 \
  --trusted-ledger-sha 569b52d99fc7ad1a5b96effacdb864422b82d00fe3fece353a7e171553f3c22b
```

The child is a public-safe exact algorithm attached to the established New K
source lineage, **not** an authenticated native GEN1056 implementation.
