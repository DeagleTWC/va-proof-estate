"""Exact source/lattice/orbit/Gram closure tests, including refusal controls."""

import copy
import json
from pathlib import Path
from hashlib import sha256
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest

from lattice_closure import (
    galois_orbits, intersection_dimension, inspect_lattice,
    replay_lattice,
)


ROOT = Path(__file__).resolve().parent
SOURCE = json.loads((ROOT / "hodge_parent_v3_source_receipt.json").read_text())
LEDGER = json.loads((ROOT / "hodge_identified_v1_ledger.json").read_text())
REGEN = json.loads((ROOT / "pinned_fermat_quintic_regenerated_receipt.json").read_text())
SOURCE_PIN = "7966f67398ea83bbb8e4ec88e57f7307014148a0bbf8fdb37af7924f7e9d2d23"
LEDGER_PIN = "569b52d99fc7ad1a5b96effacdb864422b82d00fe3fece353a7e171553f3c22b"


def restamp(value):
    body = {k: v for k, v in value.items() if k != "sha256"}
    value["sha256"] = sha256(json.dumps(body, sort_keys=True,
                                      ensure_ascii=True,
                                      separators=(",", ":")).encode()).hexdigest()


class LatticeClosureTests(unittest.TestCase):
    def test_exact_plane_intersection_categories(self):
        a = ((0, 1, 1), (2, 3, 1), (4, 5, 1))
        self.assertEqual(intersection_dimension(a, a, 5), 3)
        self.assertEqual(intersection_dimension(a,
                         ((0, 1, 3), (2, 3, 1), (4, 5, 1)), 5), 2)
        self.assertEqual(intersection_dimension(a,
                         ((0, 1, 3), (2, 3, 3), (4, 5, 1)), 5), 1)
        self.assertEqual(intersection_dimension(a,
                         ((0, 1, 3), (2, 3, 3), (4, 5, 3)), 5), 0)

    def test_galois_orbits_partition_1875_with_exact_sizes(self):
        groups = galois_orbits(LEDGER["generated_planes"])
        self.assertEqual(len(groups), 480)
        self.assertEqual(sum(len(g["member_indices"]) for g in groups), 1875)
        self.assertEqual(sum(len(g["member_indices"]) == 1 for g in groups), 15)
        self.assertEqual(sum(len(g["member_indices"]) == 4 for g in groups), 465)
        self.assertEqual(len({i for g in groups for i in g["member_indices"]}), 1875)

    def test_complete_lattice_closure_carries_and_emits_exact_gram(self):
        receipt, evidence = inspect_lattice(
            SOURCE, LEDGER, REGEN, trusted_source_sha256=SOURCE_PIN,
            trusted_ledger_sha256=LEDGER_PIN)
        self.assertEqual(receipt["gate"], "CARRY")
        self.assertTrue(all(receipt["invariants"].values()))
        self.assertEqual(receipt["generated_planes"], 1875)
        self.assertEqual(receipt["galois_orbits"], 480)
        self.assertEqual(receipt["selected_cycle_count"], 401)
        self.assertEqual(receipt["determinant_mod_1009"], 437)
        self.assertEqual(receipt["gram_sha256"],
                         "091350e197c318cf910b57c2153ea2de45d9f7cc9517c2f548a7e3fee01ad834")
        self.assertEqual(len(evidence["gram_matrix"]), 401)
        self.assertEqual(len(evidence["gram_matrix"][0]), 401)
        self.assertEqual(evidence["gram_matrix"][0][0], 13)
        self.assertTrue(replay_lattice(
            receipt, SOURCE, LEDGER, REGEN,
            trusted_source_sha256=SOURCE_PIN, trusted_ledger_sha256=LEDGER_PIN))

    def test_rehashed_altered_identifier_carrier_is_refused(self):
        forged = copy.deepcopy(LEDGER)
        forged["generated_planes"][0]["object_id"] = "VA:OBJECT:" + "0" * 64
        restamp(forged)
        result, _ = inspect_lattice(SOURCE, forged, REGEN,
                                    trusted_source_sha256=SOURCE_PIN,
                                    trusted_ledger_sha256=LEDGER_PIN)
        self.assertEqual(result["gate"], "REFUSE")
        self.assertFalse(result["invariants"]["I1_source_custody"])

    def test_rehashed_changed_regeneration_indices_cannot_carry(self):
        forged = copy.deepcopy(REGEN)
        forged["witness_plane_indices"][0] = 1875
        restamp(forged)
        result, _ = inspect_lattice(SOURCE, LEDGER, forged,
                                    trusted_source_sha256=SOURCE_PIN,
                                    trusted_ledger_sha256=LEDGER_PIN)
        self.assertEqual(result["gate"], "REFUSE")

    def test_rehashed_forged_closure_verdict_fails_full_replay(self):
        receipt, _ = inspect_lattice(SOURCE, LEDGER, REGEN,
                                      trusted_source_sha256=SOURCE_PIN,
                                      trusted_ledger_sha256=LEDGER_PIN)
        forged = copy.deepcopy(receipt)
        forged["gate"] = "REFUSE"
        forged["standing_inherited"] = False
        restamp(forged)
        self.assertFalse(replay_lattice(
            forged, SOURCE, LEDGER, REGEN,
            trusted_source_sha256=SOURCE_PIN,
            trusted_ledger_sha256=LEDGER_PIN))

    def test_changed_condition_requires_reexamination(self):
        result, _ = inspect_lattice(SOURCE, LEDGER, REGEN,
                                    trusted_source_sha256=SOURCE_PIN,
                                    trusted_ledger_sha256=LEDGER_PIN,
                                    conditions={"degree": 6, "ambient_variables": 6})
        self.assertEqual(result["gate"], "REEXAMINE")
        self.assertFalse(result["standing_inherited"])

    def test_cli_issue_and_replay_from_frozen_package(self):
        cli = ROOT / "lattice_closure_cli.py"
        with TemporaryDirectory() as temp:
            prefix = str(Path(temp) / "lattice")
            result = subprocess.run(
                [sys.executable, str(cli), "run", "--output-prefix", prefix,
                 "--trusted-source-sha", SOURCE_PIN,
                 "--trusted-ledger-sha", LEDGER_PIN],
                capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("LATTICE_GATE CARRY", result.stdout)
            result = subprocess.run(
                [sys.executable, str(cli), "replay", "--output-prefix", prefix,
                 "--trusted-source-sha", SOURCE_PIN,
                 "--trusted-ledger-sha", LEDGER_PIN],
                capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("LATTICE_REPLAY_OK", result.stdout)


if __name__ == "__main__":
    unittest.main()
