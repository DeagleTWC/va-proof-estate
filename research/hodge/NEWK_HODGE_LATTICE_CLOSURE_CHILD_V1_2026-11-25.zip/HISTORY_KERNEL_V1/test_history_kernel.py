"""Proof-before-power history continuity regression, including the Hodge omission."""

import copy
import unittest

from history_kernel import _digest, create_contract, evaluate, make_evidence, replay
from history_verifiers import verify_rank_closure


SOURCE = "a" * 64


class HistoryKernelTests(unittest.TestCase):
    def setUp(self):
        self.evidence = [
            make_evidence("edge", "EDGE_LATTICE", "DECLARED_X",
                          {"initial_rank": 10, "basis": ["H", "L1", "L2"]}),
            make_evidence("rational", "RATIONAL_CLASS", "DECLARED_X",
                          {"rational_rank": 401}),
            make_evidence("cycle", "CYCLE_CONSTRUCTION", "DECLARED_X",
                          {"regenerated_rank": 401, "planes": 1875}),
        ]
        self.contract = create_contract(
            stream_id="HODGE_X5", question="UNRESTRICTED_HODGE",
            source_sha256=SOURCE, scope="DECLARED_X", evidence=self.evidence)
        self.request = {
            "event_id": "hodge-parent-v3-1", "sequence": 0,
            "previous_receipt_sha256": None,
            "stream_id": "HODGE_X5", "question": "UNRESTRICTED_HODGE",
            "source_sha256": SOURCE, "scope": "DECLARED_X",
            "conditions": {"degree": 5, "ambient_variables": 6},
            "consumed_evidence_ids": ["edge", "rational", "cycle"],
        }

    def test_complete_exact_chain_carries_without_proving_math_from_history(self):
        receipt = evaluate(self.contract, self.evidence, self.request,
                           trusted_contract_sha256=self.contract["sha256"],
                           consumption_verifier=verify_rank_closure)
        self.assertEqual(receipt["gate"], "CARRY")
        self.assertEqual(receipt["invariants"], {
            "I1_identity": True, "I2_continuity": True,
            "I3_evidence_custody": True, "I4_evidence_consumption": True,
            "I5_conditions_unchanged": True,
        })
        self.assertFalse(receipt["mathematical_claim_verified_by_history"])
        self.assertTrue(replay(receipt, contract=self.contract, evidence=self.evidence,
                               trusted_contract_sha256=self.contract["sha256"],
                               consumption_verifier=verify_rank_closure))

    def test_hodge_missing_edge_in_decision_is_refused(self):
        missing = {**self.request, "consumed_evidence_ids": ["rational", "cycle"]}
        receipt = evaluate(self.contract, self.evidence, missing,
                           trusted_contract_sha256=self.contract["sha256"],
                           consumption_verifier=verify_rank_closure)
        self.assertEqual(receipt["gate"], "REFUSE")
        self.assertFalse(receipt["invariants"]["I4_evidence_consumption"])
        self.assertEqual(receipt["missing_consumed_evidence_ids"], ["edge"])

    def test_forged_and_rehashed_edge_fails_frozen_contract(self):
        forged = copy.deepcopy(self.evidence)
        forged[0] = make_evidence("edge", "EDGE_LATTICE", "DECLARED_X",
                                  {"initial_rank": 401, "basis": ["H", "L1", "L2"]})
        receipt = evaluate(self.contract, forged, self.request,
                           trusted_contract_sha256=self.contract["sha256"],
                           consumption_verifier=verify_rank_closure)
        self.assertEqual(receipt["gate"], "REFUSE")
        self.assertFalse(receipt["invariants"]["I3_evidence_custody"])

    def test_changed_condition_reexamines_not_silently_carries(self):
        first = evaluate(self.contract, self.evidence, self.request,
                         trusted_contract_sha256=self.contract["sha256"],
                         consumption_verifier=verify_rank_closure)
        changed = {**self.request, "event_id": "hodge-parent-v3-2",
                   "sequence": 1, "previous_receipt_sha256": first["sha256"],
                   "conditions": {"degree": 6, "ambient_variables": 6}}
        result = evaluate(self.contract, self.evidence, changed, prior=first,
                          trusted_contract_sha256=self.contract["sha256"],
                          trusted_tip_sha256=first["sha256"],
                          consumption_verifier=verify_rank_closure)
        self.assertEqual(result["gate"], "REEXAMINE")
        self.assertFalse(result["invariants"]["I5_conditions_unchanged"])
        self.assertTrue(replay(result, contract=self.contract, evidence=self.evidence,
                               trusted_contract_sha256=self.contract["sha256"],
                               prior=first, trusted_tip_sha256=first["sha256"],
                               consumption_verifier=verify_rank_closure))

    def test_prior_receipt_fork_does_not_inherit_standing(self):
        first = evaluate(self.contract, self.evidence, self.request,
                         trusted_contract_sha256=self.contract["sha256"],
                         consumption_verifier=verify_rank_closure)
        second = {**self.request, "event_id": "hodge-parent-v3-2", "sequence": 1,
                  "previous_receipt_sha256": "b" * 64}
        result = evaluate(self.contract, self.evidence, second, prior=first,
                          trusted_contract_sha256=self.contract["sha256"],
                          trusted_tip_sha256=first["sha256"],
                          consumption_verifier=verify_rank_closure)
        self.assertEqual(result["gate"], "REFUSE")
        self.assertFalse(result["invariants"]["I2_continuity"])

    def test_single_x_data_cannot_promote_to_all_x(self):
        lifted = {**self.request, "scope": "ALL_X"}
        result = evaluate(self.contract, self.evidence, lifted,
                          trusted_contract_sha256=self.contract["sha256"],
                          consumption_verifier=verify_rank_closure)
        self.assertEqual(result["gate"], "REFUSE")
        self.assertFalse(result["invariants"]["I4_evidence_consumption"])

    def test_rehashed_gate_tamper_does_not_survive_replay(self):
        receipt = evaluate(self.contract, self.evidence, self.request,
                           trusted_contract_sha256=self.contract["sha256"],
                           consumption_verifier=verify_rank_closure)
        forged = copy.deepcopy(receipt)
        forged["gate"] = "REFUSE"
        forged["sha256"] = _digest({k: v for k, v in forged.items() if k != "sha256"})
        # Even a correctly rehashed false gate fails a full source replay.
        self.assertFalse(replay(forged, contract=self.contract, evidence=self.evidence,
                                trusted_contract_sha256=self.contract["sha256"],
                                consumption_verifier=verify_rank_closure))

    def test_unverified_consumption_cannot_carry_a_self_declared_list(self):
        receipt = evaluate(self.contract, self.evidence, self.request,
                           trusted_contract_sha256=self.contract["sha256"])
        self.assertEqual(receipt["gate"], "REFUSE")
        self.assertFalse(receipt["invariants"]["I4_evidence_consumption"])

    def test_missing_external_contract_anchor_refuses_even_real_replay(self):
        receipt = evaluate(self.contract, self.evidence, self.request,
                           consumption_verifier=verify_rank_closure)
        self.assertEqual(receipt["gate"], "REFUSE")
        self.assertFalse(receipt["invariants"]["I3_evidence_custody"])

    def test_claimed_edge_use_fails_if_replay_only_reads_two_other_carriers(self):
        def broken_source_replay(carriers, _request):
            ranks = {item["kind"]: item["body"] for item in carriers}
            if ranks["RATIONAL_CLASS"]["rational_rank"] == ranks["CYCLE_CONSTRUCTION"]["regenerated_rank"]:
                return {"verified": True, "used_evidence_ids": ["rational", "cycle"]}
            return {"verified": False, "used_evidence_ids": []}

        result = evaluate(self.contract, self.evidence, self.request,
                          trusted_contract_sha256=self.contract["sha256"],
                          consumption_verifier=broken_source_replay)
        self.assertEqual(result["gate"], "REFUSE")
        self.assertEqual(result["missing_consumed_evidence_ids"], ["edge"])


if __name__ == "__main__":
    unittest.main()
