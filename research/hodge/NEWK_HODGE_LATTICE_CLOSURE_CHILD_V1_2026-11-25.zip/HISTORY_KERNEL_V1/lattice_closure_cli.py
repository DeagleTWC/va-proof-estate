#!/usr/bin/env python3
"""Exact lattice closure issue and replay for the frozen Fermat quintic."""

import argparse
import json
from pathlib import Path
import sys

from history_cli import _write_atomic
from lattice_closure import inspect_lattice, replay_lattice


ROOT = Path(__file__).resolve().parent
SOURCE_FILE = ROOT / "hodge_parent_v3_source_receipt.json"
LEDGER_FILE = ROOT / "hodge_identified_v1_ledger.json"
REGEN_FILE = ROOT / "pinned_fermat_quintic_regenerated_receipt.json"


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    for action in ("run", "replay"):
        command = sub.add_parser(action)
        command.add_argument("--source", type=Path, default=SOURCE_FILE)
        command.add_argument("--ledger", type=Path, default=LEDGER_FILE)
        command.add_argument("--regeneration", type=Path, default=REGEN_FILE)
        command.add_argument("--trusted-source-sha", required=True)
        command.add_argument("--trusted-ledger-sha", required=True)
        command.add_argument("--output-prefix", required=True)
        if action == "run":
            command.add_argument("--conditions-json", type=Path)
    args = parser.parse_args(argv)
    source = json.loads(args.source.read_text(encoding="utf-8"))
    ledger = json.loads(args.ledger.read_text(encoding="utf-8"))
    regeneration = json.loads(args.regeneration.read_text(encoding="utf-8"))
    receipt_file = Path(args.output_prefix + "_receipt.json")
    evidence_file = Path(args.output_prefix + "_exact_evidence.json")
    named = {"trusted_source_sha256": args.trusted_source_sha,
             "trusted_ledger_sha256": args.trusted_ledger_sha}
    if args.action == "run":
        conditions = (json.loads(args.conditions_json.read_text(encoding="utf-8"))
                      if args.conditions_json is not None else None)
        receipt, evidence = inspect_lattice(
            source, ledger, regeneration, conditions=conditions, **named)
        _write_atomic(receipt_file, receipt)
        _write_atomic(evidence_file, evidence)
        print("LATTICE_GATE", receipt["gate"])
        print("ORBIT_COUNT", receipt["galois_orbits"])
        print("GRAM_MOD_1009", receipt["determinant_mod_1009"])
        return {"CARRY": 0, "REEXAMINE": 2, "REFUSE": 3}[receipt["gate"]]
    try:
        recorded = json.loads(receipt_file.read_text(encoding="utf-8"))
        stored_evidence = json.loads(evidence_file.read_text(encoding="utf-8"))
        reissued, computed_evidence = inspect_lattice(
            source, ledger, regeneration, conditions=recorded["conditions"], **named)
        success = (recorded == reissued and stored_evidence == computed_evidence
                   and replay_lattice(recorded, source, ledger, regeneration, **named))
    except (OSError, KeyError, TypeError, ValueError):
        success = False
    print("LATTICE_REPLAY_OK" if success else "LATTICE_REPLAY_REFUSE")
    return 0 if success else 3


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, TypeError, KeyError) as error:
        print(f"LATTICE_REFUSE: {error}", file=sys.stderr)
        sys.exit(3)
