"""Public-safe exact source-consumption rules for the History Kernel.

A branch must supply its own trusted replay rule, never a self-asserted list.
This Hodge example reads all three exact integer carriers and verifies their
arithmetic consistency. It does NOT prove their underlying geometric validity.
"""


def verify_rank_closure(carriers, _request):
    """Actual reads: edge rank, rational dimension, regenerated cycle rank."""
    kinds = {item["kind"]: item for item in carriers}
    expected = {"EDGE_LATTICE", "RATIONAL_CLASS", "CYCLE_CONSTRUCTION"}
    if set(kinds) != expected:
        return {"verified": False, "used_evidence_ids": []}
    edge = kinds["EDGE_LATTICE"]
    rational = kinds["RATIONAL_CLASS"]
    cycles = kinds["CYCLE_CONSTRUCTION"]
    edge_rank = edge["body"].get("initial_lattice_rank",
                                  edge["body"].get("initial_rank"))
    rational_rank = rational["body"].get("rational_hodge_rank",
                                              rational["body"].get("rational_rank"))
    cycle_rank = cycles["body"].get("cycle_rank",
                                       cycles["body"].get("regenerated_rank"))
    verified = (all(type(v) is int and v >= 0
                    for v in (edge_rank, rational_rank, cycle_rank))
                and edge_rank <= cycle_rank == rational_rank)
    return {"verified": verified,
            "used_evidence_ids": [edge["id"], rational["id"], cycles["id"]]}
