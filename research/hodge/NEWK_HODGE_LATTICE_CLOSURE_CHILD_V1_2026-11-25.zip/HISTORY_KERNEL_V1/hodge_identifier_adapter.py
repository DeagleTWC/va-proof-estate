"""Bind exact child identifiers into the existing Hodge History continuity gate.

No accepted ID comes from a caller's label or unenumerated plane count.
The source-replay verifier independently rederives the identity ledger.
"""

import json
from pathlib import Path

from history_kernel import create_contract, make_evidence
from history_verifiers import verify_rank_closure
from hodge_history_adapter import build_hodge_case
from identifier_kernel import _id, issue_hodge_identifiers, replay_hodge_identifiers


def _event_id(request, ledger_id):
    return _id("EVENT", {
        "stream_id": request["stream_id"], "source_sha256": request["source_sha256"],
        "sequence": request["sequence"], "question": request["question"],
        "scope": request["scope"], "conditions": request["conditions"],
        "previous_receipt_sha256": request["previous_receipt_sha256"],
        "identifier_ledger_id": ledger_id,
    })


def build_identified_hodge_case(source_path, *, trusted_source_sha256,
                                omit_identifiers=False):
    base = build_hodge_case(source_path,
                            trusted_source_sha256=trusted_source_sha256)
    source = json.loads(Path(source_path).read_text(encoding="utf-8"))
    ledger = issue_hodge_identifiers(source, trusted_source_sha256)
    if ledger["gate"] != "ISSUE":
        raise ValueError("IDENTIFIER_ISSUANCE_REFUSED")
    identifier_carrier = make_evidence(
        "identifiers", "EXACT_IDENTITY_LEDGER", "DECLARED_X", {"ledger": ledger})
    evidence = [*base["evidence"], identifier_carrier]
    contract = create_contract(stream_id=base["request"]["stream_id"],
                               question=base["request"]["question"],
                               source_sha256=trusted_source_sha256,
                               scope=base["request"]["scope"], evidence=evidence)
    request = dict(base["request"])
    request["event_id"] = _event_id(request, ledger["ledger_id"])
    if not omit_identifiers:
        request["consumed_evidence_ids"] = [
            *request["consumed_evidence_ids"], "identifiers"]
    return ({"contract": contract, "evidence": evidence, "request": request,
             "consumption_verifier_id": "HODGE_RANK_AND_IDENTIFIERS_V1",
             "trusted_contract_sha256": contract["sha256"],
             "trusted_source_sha256": trusted_source_sha256}, ledger)


def identity_history_verifier(source_path, trusted_source_sha256):
    """Registered source reader; replays parent ranks AND identifier ledger."""
    def verify(carriers, request):
        refused = {"verified": False, "used_evidence_ids": []}
        try:
            kinds = {x["kind"]: x for x in carriers}
            if len(kinds) != 4 or set(kinds) != {
                "EDGE_LATTICE", "RATIONAL_CLASS", "CYCLE_CONSTRUCTION",
                "EXACT_IDENTITY_LEDGER",
            }:
                return refused
            rank = verify_rank_closure(
                [x for x in carriers if x["kind"] != "EXACT_IDENTITY_LEDGER"], request)
            if not rank["verified"]:
                return refused
            source = json.loads(Path(source_path).read_text(encoding="utf-8"))
            ledger = kinds["EXACT_IDENTITY_LEDGER"]["body"]["ledger"]
            if (not replay_hodge_identifiers(ledger, source, trusted_source_sha256)
                    or ledger["gate"] != "ISSUE"
                    or request["event_id"] != _event_id(request, ledger["ledger_id"])):
                return refused
            return {"verified": True,
                    "used_evidence_ids": [*rank["used_evidence_ids"],
                                          kinds["EXACT_IDENTITY_LEDGER"]["id"]]}
        except (OSError, ValueError, KeyError, TypeError, IndexError):
            return refused
    return verify
