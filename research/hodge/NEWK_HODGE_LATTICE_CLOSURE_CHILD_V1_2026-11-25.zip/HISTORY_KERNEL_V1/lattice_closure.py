#!/usr/bin/env python3
"""Exact Hodge X5 lattice closure child: identity → orbit → Gram → rank.

No fitted values, floating point or silent promotion of an unrestricted claim.
This child replays a fixed source scope; changed conditions stop inheritance.
"""

from collections import deque
from hashlib import sha256
from itertools import product
from pathlib import Path

from history_kernel import _check_exact, _digest, _stamped, _valid_stamp
from identifier_kernel import _perfect_matchings, replay_hodge_identifiers


SCHEMA = "VA_NEWK_EXACT_LATTICE_CLOSURE_CHILD_V1"
MODULUS = 10
PRIME = 1009
UNITS = (1, 3, 7, 9)
PINNED_SOURCE_GRAM_SHA256 = "091350e197c318cf910b57c2153ea2de45d9f7cc9517c2f548a7e3fee01ad834"
INVARIANTS = (
    "I1_source_custody", "I2_geometry_identity", "I3_galois_orbits",
    "I4_exact_intersection_witness", "I5_rational_cycle_closure",
)
DECLARED_CONDITIONS = {"degree": 5, "ambient_variables": 6}


def intersection_dimension(left, right, degree):
    """Exact vector-space intersection dimension from cyclotomic relations.

    A consistent connected component contributes one free projective-cone
    coordinate; a nonzero phase around a cycle forces that component to zero.
    """
    if type(degree) is not int or degree < 2:
        raise ValueError("NONEXACT_DEGREE")
    modulus = 2 * degree
    edges = [[] for _ in range(6)]
    for plane in (left, right):
        if not isinstance(plane, (list, tuple)) or len(plane) != 3:
            raise ValueError("PLANE_NEEDS_THREE_PAIRS")
        seen = set()
        for pair in plane:
            if (not isinstance(pair, (list, tuple)) or len(pair) != 3
                    or any(type(x) is not int for x in pair)):
                raise ValueError("NONEXACT_PAIR")
            i, j, exponent = pair
            if (not 0 <= i < j < 6 or exponent not in range(1, modulus, 2)
                    or i in seen or j in seen):
                raise ValueError("INVALID_PAIRING_OR_PHASE")
            seen.update((i, j))
            # Relation w_i - w_j = exponent (mod 2d).
            edges[i].append((j, -exponent))
            edges[j].append((i, exponent))
        if seen != set(range(6)):
            raise ValueError("INCOMPLETE_PERFECT_MATCHING")
    potentials = [None] * 6
    consistent_components = 0
    for start in range(6):
        if potentials[start] is not None:
            continue
        potentials[start] = 0
        queue = deque([start])
        consistent = True
        while queue:
            i = queue.popleft()
            for j, change in edges[i]:
                value = (potentials[i] + change) % modulus
                if potentials[j] is None:
                    potentials[j] = value
                    queue.append(j)
                elif potentials[j] != value:
                    consistent = False
        if consistent:
            consistent_components += 1
    return consistent_components


def _enumerate_pinned_plane_pairs():
    """Independent finite realization of the SHA-pinned Fermat rule."""
    return (
        [[i, j, k] for (i, j), k in zip(matching, roots)]
        for matching in _perfect_matchings(tuple(range(6)))
        for roots in product((1, 3, 5, 7, 9), repeat=3)
    )


def galois_orbits(plane_records):
    """Partition exact planes under Gal(Q(ζ10)/Q)=(Z/10Z)* action."""
    if not isinstance(plane_records, list) or not plane_records:
        raise ValueError("NO_PLANE_IDENTITIES")
    seen = set()
    groups = {}
    for record in plane_records:
        triples = record["pairs"]
        if (not isinstance(triples, list) or len(triples) != 3
                or type(record.get("index")) is not int
                or type(record.get("object_id")) is not str
                or record["index"] in seen):
            raise ValueError("INVALID_PLANE_RECORD")
        seen.add(record["index"])
        raw = tuple(tuple(x) for x in triples)
        if (any(len(x) != 3 or any(type(v) is not int for v in x)
                for x in raw)
                or any(x[2] not in (1, 3, 5, 7, 9) for x in raw)):
            raise ValueError("MALFORMED_GALOIS_PHASE")
        orbit = [tuple((i, j, (k * unit) % MODULUS)
                       for i, j, k in raw) for unit in UNITS]
        canonical = min(orbit)
        groups.setdefault(canonical, []).append(record)
    output = []
    for key in sorted(groups):
        members = groups[key]
        ordered_indices = sorted(x["index"] for x in members)
        ordered_ids = sorted(x["object_id"] for x in members)
        orbit_id = "VA:GALOIS_ORBIT:" + _digest({
            "schema": SCHEMA, "modulus": MODULUS,
            "canonical_pairs": [list(x) for x in key], "object_ids": ordered_ids,
        })
        output.append({"orbit_id": orbit_id,
                       "canonical_pairs": [list(x) for x in key],
                       "member_indices": ordered_indices,
                       "member_object_ids": ordered_ids})
    return output


def _mod_determinant(integer_matrix, prime):
    """Exact prime-field elimination; no floating pivots or tolerances."""
    n = len(integer_matrix)
    if n == 0 or any(len(row) != n for row in integer_matrix):
        raise ValueError("GRAM_NOT_SQUARE")
    matrix = [[value % prime for value in row] for row in integer_matrix]
    determinant = 1
    for col in range(n):
        pivot_row = next((r for r in range(col, n)
                          if matrix[r][col] != 0), None)
        if pivot_row is None:
            return 0
        if pivot_row != col:
            matrix[col], matrix[pivot_row] = matrix[pivot_row], matrix[col]
            determinant = -determinant
        current = matrix[col]
        pivot = current[col]
        determinant = determinant * pivot % prime
        inverse = pow(pivot, -1, prime)
        for row in range(col + 1, n):
            target = matrix[row]
            factor = target[col] * inverse % prime
            if factor:
                for j in range(col + 1, n):
                    target[j] = (target[j] - factor * current[j]) % prime
            target[col] = 0
    return determinant % prime


def _gram_of_selected(planes, indices, degree):
    if (not isinstance(indices, list) or len(indices) != 401
            or any(type(i) is not int or i < 0 or i >= len(planes)
                   for i in indices) or len(set(indices)) != len(indices)):
        raise ValueError("INVALID_401_WITNESS_SELECTION")
    selected = [tuple(tuple(pair) for pair in planes[i]["pairs"])
                for i in indices]
    matrix = [[0] * len(indices) for _ in indices]
    pairing = (0, 1, 2 - degree, degree * degree - 3 * degree + 3)
    for i in range(len(indices)):
        for j in range(i, len(indices)):
            value = pairing[intersection_dimension(selected[i], selected[j], degree)]
            matrix[i][j] = matrix[j][i] = value
    return matrix


def inspect_lattice(source, ledger, regeneration, *, trusted_source_sha256,
                    trusted_ledger_sha256, conditions=None):
    """One exact, nonactuating gate. Return (stamped receipt, evidence data)."""
    invariants = dict.fromkeys(INVARIANTS, False)
    receipt = {"schema": SCHEMA, "gate": "REFUSE", "invariants": invariants,
               "source_sha256": trusted_source_sha256,
               "identifier_ledger_sha256": trusted_ledger_sha256,
               "regeneration_sha256": regeneration.get("sha256")
               if isinstance(regeneration, dict) and
               type(regeneration.get("sha256")) is str else None,
               "conditions": conditions if conditions is not None else DECLARED_CONDITIONS,
               "generated_planes": 0, "galois_orbits": 0,
               "selected_cycle_count": 0, "determinant_mod_1009": None,
               "gram_sha256": None, "galois_orbit_sha256": None,
               "standing_inherited": False,
               "unrestricted_hodge_proved_by_this_child": False,
               "rational_character_theorem_independently_reproved": False}
    evidence = {"gram_matrix": [], "orbits": [], "witness_plane_indices": [],
                "witness_object_ids": []}
    try:
        _check_exact(receipt["conditions"])
        if (not isinstance(source, dict) or not isinstance(ledger, dict)
                or not isinstance(regeneration, dict)
                or not _valid_stamp(source) or not _valid_stamp(regeneration)
                or source["sha256"] != trusted_source_sha256
                or ledger.get("sha256") != trusted_ledger_sha256
                or regeneration["sha256"] != source["regeneration_passes"][-1]["source_receipt_sha256"]
                or sha256((Path(__file__).resolve().parent /
                           "pinned_fermat_family_regenerator.py").read_bytes()).hexdigest()
                != source["source_custody"]["fermat_family_regenerator.py"]
                or not replay_hodge_identifiers(ledger, source, trusted_source_sha256)):
            return _stamped(receipt), evidence
        invariants["I1_source_custody"] = True
        planes = ledger["generated_planes"]
        expected = _enumerate_pinned_plane_pairs()
        invariants["I2_geometry_identity"] = (
            len(planes) == 1875
            and all(item["index"] == index and item["pairs"] == pair
                    for index, (item, pair) in enumerate(zip(planes, expected))))
        if not invariants["I2_geometry_identity"]:
            return _stamped(receipt), evidence
        groups = galois_orbits(planes)
        sizes = [len(group["member_indices"]) for group in groups]
        invariants["I3_galois_orbits"] = (
            len(groups) == 480 and sizes.count(1) == 15
            and sizes.count(4) == 465
            and sum(sizes) == 1875)
        if not invariants["I3_galois_orbits"]:
            return _stamped(receipt), evidence
        indices = regeneration["witness_plane_indices"]
        matrix = _gram_of_selected(planes, indices, 5)
        determinant = _mod_determinant(matrix, PRIME)
        invariants["I4_exact_intersection_witness"] = (
            determinant == regeneration["determinant_mod_1009"] == 437
            and all(matrix[i][i] == 13 for i in range(401))
            and _digest(matrix) == PINNED_SOURCE_GRAM_SHA256)
        invariants["I5_rational_cycle_closure"] = (
            len(indices) == regeneration["certified_algebraic_rank_lower_bound"]
            == regeneration["rational_hodge_dimension"]
            == source["rational_hodge_rank_for_declared_x"]
            == source["final_declared_cycle_rank"] == 401
            and source["initial_declared_cycle_rank"] == 10
            and regeneration["status"] == "EXACT_CYCLE_SPAN")
        evidence = {"gram_matrix": matrix, "orbits": groups,
                    "witness_plane_indices": indices,
                    "witness_object_ids": [planes[i]["object_id"] for i in indices]}
        receipt.update({"generated_planes": len(planes),
                        "galois_orbits": len(groups),
                        "selected_cycle_count": len(indices),
                        "determinant_mod_1009": determinant,
                        "gram_sha256": _digest(matrix),
                        "galois_orbit_sha256": _digest(groups)})
        if not all(invariants.values()):
            return _stamped(receipt), evidence
        if receipt["conditions"] != DECLARED_CONDITIONS:
            receipt["gate"] = "REEXAMINE"
        else:
            receipt["gate"] = "CARRY"
            receipt["standing_inherited"] = True
    except (KeyError, IndexError, OSError, TypeError, ValueError,
            ZeroDivisionError, ArithmeticError):
        return _stamped(receipt), evidence
    return _stamped(receipt), evidence


def replay_lattice(receipt, source, ledger, regeneration, *,
                   trusted_source_sha256, trusted_ledger_sha256):
    """Require full independent recomputation, not a plausible rehashed label."""
    try:
        if not _valid_stamp(receipt):
            return False
        expected, _ = inspect_lattice(source, ledger, regeneration,
                                      trusted_source_sha256=trusted_source_sha256,
                                      trusted_ledger_sha256=trusted_ledger_sha256,
                                      conditions=receipt["conditions"])
        return receipt == expected
    except (TypeError, ValueError, KeyError):
        return False
