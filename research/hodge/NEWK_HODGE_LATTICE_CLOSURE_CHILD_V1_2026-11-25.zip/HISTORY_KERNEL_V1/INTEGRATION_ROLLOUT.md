# History Continuity Kernel — Application Map

**Principle:** A single canonical pre-consequence kernel; domain-specific
replay adapters. No independent copy of the standing law per application.

| V.A. branch | History obligation | Present integration state |
|---|---|---|
| Hodge/New K mathematical examiner | Edge actually consumed; rational and cycle receipts linked; scope stable | **EXECUTABLE DEMONSTRATION**, original v3 receipt frozen; new 1,875-plane identifier child and four-carrier History replay |
| Proof Estate publications | Author source, formula, exact evidence and changed-version lineage before release | Interface mapped; not wired into publication CI |
| P vs NP examinations | Θ17→Θ10 source commitments and reversible-descent history | Adapter specification pending source-level contract |
| Navier–Stokes examinations | Signed flux/time identity and changed-condition replay | Adapter specification pending authenticated native rule |
| Other mathematics / HH / NEXUS | Every child conclusion tied to parent inputs and actual consumption trace | Ready to implement per-source verifiers |
| Frankie / Natural Order Teacher | No learned or acted consequence inherits a forked/unverified history | **NOT DEPLOYED**; requires native service API and maintenance window |
| Engineering / physical pilots | Apparatus ID, calibrated witness, independent measurement, lawful condition changes | **NOT DEPLOYED**; must not substitute software hash for physical evidence |
| Universe research | Hypothesis, observation, source and condition lineage | Ready as a research adapter; no cosmic claim asserted |

## Required integration contract

Each host provides, from trusted custody rather than from a caller payload:

1. Frozen source/question/scope contract and its pinned digest.
2. Latest accepted receipt hash (`trusted_tip_sha256`) for non-genesis events.
3. A deterministic source-replay verifier that **reads the required evidence**
   and returns observed IDs and a verified decision, not an asserted read-list.
4. A pre-consequence enforcement point where only `CARRY` can proceed.
5. Changed-condition `REEXAMINE` and invalid `REFUSE` both stop old standing.
6. Object identities come from source-backed canonical geometric descriptions;
   record identities bind each object to exact provenance. Missing source
   enumerations must be refused, not filled from aggregate counts.

If any item is missing, the branch stays **not integrated**. No live services,
site publishing rules, production AI, or physical equipment were changed by
this reference package. That separation protects the established V.A. work.
