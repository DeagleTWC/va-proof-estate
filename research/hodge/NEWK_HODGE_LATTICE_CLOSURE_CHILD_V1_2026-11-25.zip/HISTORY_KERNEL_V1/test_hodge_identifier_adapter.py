"""Identifier child must be actually consumed by the parent History gate."""

from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest

from history_kernel import evaluate, make_evidence, create_contract, replay
from hodge_identifier_adapter import (
    build_identified_hodge_case, identity_history_verifier,
)


SOURCE = Path(__file__).resolve().parent / "hodge_parent_v3_source_receipt.json"
PIN = "7966f67398ea83bbb8e4ec88e57f7307014148a0bbf8fdb37af7924f7e9d2d23"


class HodgeIdentifierHistoryTests(unittest.TestCase):
    def test_exact_identifier_receipt_is_fourth_consumed_history_carrier(self):
        case, ledger = build_identified_hodge_case(SOURCE, trusted_source_sha256=PIN)
        self.assertEqual(ledger["gate"], "ISSUE")
        self.assertTrue(case["request"]["event_id"].startswith("VA:EVENT:"))
        self.assertEqual(len(case["evidence"]), 4)
        receipt = evaluate(case["contract"], case["evidence"], case["request"],
                           trusted_contract_sha256=case["trusted_contract_sha256"],
                           consumption_verifier=identity_history_verifier(SOURCE, PIN))
        self.assertEqual(receipt["gate"], "CARRY")
        self.assertEqual(receipt["observed_used_evidence_ids"],
                         ["cycles", "edge", "identifiers", "rational"])
        self.assertTrue(replay(receipt, contract=case["contract"],
                               evidence=case["evidence"],
                               trusted_contract_sha256=case["trusted_contract_sha256"],
                               consumption_verifier=identity_history_verifier(SOURCE, PIN)))

    def test_missing_identifier_consumption_refuses(self):
        case, _ = build_identified_hodge_case(
            SOURCE, trusted_source_sha256=PIN, omit_identifiers=True)
        receipt = evaluate(case["contract"], case["evidence"], case["request"],
                           trusted_contract_sha256=case["trusted_contract_sha256"],
                           consumption_verifier=identity_history_verifier(SOURCE, PIN))
        self.assertEqual(receipt["gate"], "REFUSE")
        self.assertEqual(receipt["missing_consumed_evidence_ids"], ["identifiers"])

    def test_manually_substituted_event_identifier_cannot_carry(self):
        case, _ = build_identified_hodge_case(SOURCE, trusted_source_sha256=PIN)
        request = {**case["request"], "event_id": "someone-typed-this-event-id"}
        receipt = evaluate(case["contract"], case["evidence"], request,
                           trusted_contract_sha256=case["trusted_contract_sha256"],
                           consumption_verifier=identity_history_verifier(SOURCE, PIN))
        self.assertEqual(receipt["gate"], "REFUSE")
        self.assertFalse(receipt["invariants"]["I4_evidence_consumption"])

    def test_newly_rehashed_false_identity_carrier_cannot_gain_standing(self):
        case, ledger = build_identified_hodge_case(SOURCE, trusted_source_sha256=PIN)
        fake = dict(ledger)
        fake["issued_basis_objects"] = 1875
        content = {k: v for k, v in fake.items() if k != "sha256"}
        fake["sha256"] = sha256(json.dumps(content, sort_keys=True,
                                             ensure_ascii=True,
                                             separators=(",", ":")).encode()).hexdigest()
        case["evidence"][-1] = make_evidence(
            "identifiers", "EXACT_IDENTITY_LEDGER", "DECLARED_X", {"ledger": fake})
        case["contract"] = create_contract(
            stream_id="HODGE_PARENT_V3", question=case["request"]["question"],
            source_sha256=PIN, scope="DECLARED_X", evidence=case["evidence"])
        receipt = evaluate(case["contract"], case["evidence"], case["request"],
                           trusted_contract_sha256=case["contract"]["sha256"],
                           consumption_verifier=identity_history_verifier(SOURCE, PIN))
        self.assertEqual(receipt["gate"], "REFUSE")
        self.assertFalse(receipt["invariants"]["I4_evidence_consumption"])

    def test_wrong_parent_anchor_is_not_accepted(self):
        with self.assertRaises(ValueError):
            build_identified_hodge_case(SOURCE, trusted_source_sha256="0" * 64)

    def test_cli_generates_and_independently_replays(self):
        script = Path(__file__).resolve().parent / "identifier_cli.py"
        with TemporaryDirectory() as temp:
            prefix = str(Path(temp) / "identified")
            produced = subprocess.run(
                [sys.executable, str(script), "hodge", "--source", str(SOURCE),
                 "--expected-source-sha", PIN, "--output-prefix", prefix],
                capture_output=True, text=True)
            self.assertEqual(produced.returncode, 0, produced.stderr)
            self.assertIn("IDENTIFIER_GATE ISSUE", produced.stdout)
            self.assertIn("HISTORY_GATE CARRY", produced.stdout)
            checked = subprocess.run(
                [sys.executable, str(script), "replay", "--source", str(SOURCE),
                 "--expected-source-sha", PIN, "--output-prefix", prefix,
                 "--trusted-contract-sha", json.loads(
                     Path(prefix + "_case.json").read_text())["trusted_contract_sha256"]],
                capture_output=True, text=True)
            self.assertEqual(checked.returncode, 0, checked.stderr)
            self.assertIn("IDENTIFIER_REPLAY_OK", checked.stdout)
            self.assertIn("HISTORY_REPLAY_OK", checked.stdout)


if __name__ == "__main__":
    unittest.main()
