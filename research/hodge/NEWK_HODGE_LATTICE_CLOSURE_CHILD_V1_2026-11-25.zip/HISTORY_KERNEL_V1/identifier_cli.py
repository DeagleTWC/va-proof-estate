#!/usr/bin/env python3
"""Exact child identifier issue and independently anchored History replay."""

import argparse
import json
from pathlib import Path
import sys

from history_cli import _write_atomic
from history_kernel import evaluate, replay
from hodge_identifier_adapter import (
    build_identified_hodge_case, identity_history_verifier,
)
from identifier_kernel import replay_hodge_identifiers


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("hodge", "replay"):
        command = sub.add_parser(name)
        command.add_argument("--source", required=True)
        command.add_argument("--expected-source-sha", required=True)
        command.add_argument("--output-prefix", required=True)
        if name == "replay":
            command.add_argument("--trusted-contract-sha", required=True)
        else:
            command.add_argument("--omit-identifiers", action="store_true")
    args = parser.parse_args(argv)
    paths = {key: Path(args.output_prefix + suffix) for key, suffix in (
        ("ledger", "_ledger.json"), ("case", "_case.json"),
        ("receipt", "_history_receipt.json"))}
    if args.command == "hodge":
        case, ledger = build_identified_hodge_case(
            args.source, trusted_source_sha256=args.expected_source_sha,
            omit_identifiers=args.omit_identifiers)
        receipt = evaluate(
            case["contract"], case["evidence"], case["request"],
            trusted_contract_sha256=case["trusted_contract_sha256"],
            consumption_verifier=identity_history_verifier(
                args.source, args.expected_source_sha))
        _write_atomic(paths["ledger"], ledger)
        _write_atomic(paths["case"], case)
        _write_atomic(paths["receipt"], receipt)
        print("IDENTIFIER_GATE", ledger["gate"])
        print("HISTORY_GATE", receipt["gate"])
        return {"CARRY": 0, "REEXAMINE": 2, "REFUSE": 3}[receipt["gate"]]
    try:
        case = json.loads(paths["case"].read_text(encoding="utf-8"))
        ledger = json.loads(paths["ledger"].read_text(encoding="utf-8"))
        receipt = json.loads(paths["receipt"].read_text(encoding="utf-8"))
        source = json.loads(Path(args.source).read_text(encoding="utf-8"))
        expected_case, expected_ledger = build_identified_hodge_case(
            args.source, trusted_source_sha256=args.expected_source_sha,
            omit_identifiers=("identifiers" not in case["request"]["consumed_evidence_ids"]))
        identity_ok = (ledger == expected_ledger and
                       replay_hodge_identifiers(ledger, source,
                                                args.expected_source_sha))
        history_ok = (case == expected_case and
                      case["contract"]["sha256"] == args.trusted_contract_sha and
                      replay(receipt, contract=case["contract"],
                             evidence=case["evidence"],
                             trusted_contract_sha256=args.trusted_contract_sha,
                             consumption_verifier=identity_history_verifier(
                                 args.source, args.expected_source_sha)))
    except (OSError, ValueError, TypeError, KeyError):
        identity_ok = history_ok = False
    print("IDENTIFIER_REPLAY_OK" if identity_ok else "IDENTIFIER_REPLAY_REFUSE")
    print("HISTORY_REPLAY_OK" if history_ok else "HISTORY_REPLAY_REFUSE")
    return 0 if identity_ok and history_ok else 3


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(f"IDENTIFIER_REFUSE: {error}", file=sys.stderr)
        sys.exit(3)
