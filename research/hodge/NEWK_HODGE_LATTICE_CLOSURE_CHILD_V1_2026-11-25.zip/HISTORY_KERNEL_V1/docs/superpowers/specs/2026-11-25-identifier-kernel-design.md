# V.A. Identifier Child Kernel — Design

## Intent

Provide two linked classes of deterministic identifiers *before* a History
Kernel event can inherit standing: identities for mathematical objects from
exact source descriptions, and identities for their evidence carriers and
lineage. No user-supplied alias can substitute for a derived identity.

## Scope and constraints

- Reuse the public-safe, frozen Hodge v3 receipt already in History Kernel v1.
- Require an independently supplied parent-source SHA-256 anchor. Self-hashes
  alone are not evidence of authenticity.
- Issue an exact `OBJECT` identity for nine source-listed projective row spaces
  from rational reduced-row-echelon normal forms, invariant under invertible
  rational changes of row basis. Issue a clearly labeled `CLASS` identity for
  the source's symbolic hyperplane-square class, not a fictitious geometric plane.
- Issue separate `RECORD` identities tied to their source payload and object,
  and an `IDENTITY_LEDGER` digest tied to parent source and listed basis.
- Enforce five invariants: pinned source, exact normal form, unique alias to
  identity mapping, complete *declared basis* coverage, verified linkage.
- One gate, `ISSUE` or `REFUSE`, and a deterministic receipt; no actuation.
- The parent counts 1,875 generated planes. Its separately frozen and
  SHA-256-listed `fermat_family_regenerator.py` supplies the exact 15-perfect-
  matchings × 5³ odd-cyclotomic-exponents enumeration rule. Independently
  regenerate all 1,875 descriptors from that pinned source rule; refuse if
  the generator file's bytes do not match the parent source custody hash.
  NEVER mint identities from the aggregate count alone.
- Preserve overlap: a generated plane with three exponent-5 pairings is the
  same projective plane as a listed exact rational row space, so its geometry
  object ID must be identical even though each record ID differs.
- Add a Hodge-to-History child adapter; replay must independently rederive
  identities and read the identifier carrier alongside edge/rational/cycles.
- No native GEN 1056 access, physical identity, unrestricted mathematical
  theorem verification, production deployment, or publication in this task.

## Approach

Chosen: two linked identity layers with one exact canonicalization and
receipt gate. An alias-only inventory fails when labels are reused; hashing
the raw vector listing fails under equivalent row bases. Canonical geometry
IDs with separate source-specific record IDs preserve both meanings.

## Operational boundary

`ISSUE` means identifiers are reproducible for listed basis carriers and
generated planes under pinned source and generator bytes. It does not certify
all the generator's geometric claims, personhood, ownership or a theorem.
