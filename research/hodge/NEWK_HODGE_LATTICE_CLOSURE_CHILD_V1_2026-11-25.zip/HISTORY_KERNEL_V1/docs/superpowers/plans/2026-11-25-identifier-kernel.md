# Identifier Child Kernel Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build, test and package two linked, source-derived identifier layers for the Hodge History Kernel.

**Architecture:** A pure exact identity library issues domain-separated canonical IDs and an auditable ledger. It reads frozen Hodge source and generator bytes, derives ten basis IDs plus 1,875 exact generated-plane IDs, unifies equivalent row-space IDs, and binds the ledger into History as a fourth consumed carrier. CLI provides issuance and independent replay.

**Tech Stack:** Python 3 standard library, `fractions.Fraction`, `unittest`, JSON, SHA-256.

**Spec:** `docs/superpowers/specs/2026-11-25-identifier-kernel-design.md`

## Global Constraints

- Exact integers/rational row reduction only; no floats, fitted coefficients or invented elements.
- Parent receipt independent hash `7966f67398ea83bbb8e4ec88e57f7307014148a0bbf8fdb37af7924f7e9d2d23`.
- Existing History v1 cases and 16 tests remain usable; additions do not silently change v1 receipts.
- Do not treat identifiers as proof of the unrestricted Hodge Conjecture.

## Review Focus

- Equivalent row bases: geometry ID stable, source record ID reflects changed source.
- Duplicate aliases, duplicated geometries and malformed row matrices: refuse or distinguish explicitly.
- Rehashed forged source or ledger: independent source pin or recomputation must refuse.
- Summarized 1,875 plane count: identities must be derived from separately pinned generator bytes, never merely the count.
- History consumption: omitting the identity carrier must refuse even when edge/rational/cycle pass.

---

### Task 1: Exact core identity and ledger

**Files:** Create `identifier_kernel.py`, `test_identifier_kernel.py`.

**Interfaces:** `canonical_row_space(rows, ambient_columns)` returns exact string rational normal form; `issue_hodge_identifiers(source, trusted_source_sha256)` returns stamped ledger with `gate`, five invariants and linked `objects`; `replay_hodge_identifiers(ledger, source, trusted_source_sha256)` returns Boolean.

- [ ] Write tests for canonical equivalence, distinct geometric row spaces, symbolic H, ten listed IDs and 1,875 pinned-generator IDs, refusal of malformed/duplicate/faked data, and replay of a rehashed forged verdict.
- [ ] Run focused unittest and observe failure because the interface is absent.
- [ ] Implement minimal pure exact normalizer, domain separated IDs, source-pinned issue and replay.
- [ ] Run focused unittest to green and existing suite to green.

### Task 2: Hodge History binding and CLI

**Files:** Create `hodge_identifier_adapter.py`, `identifier_cli.py`, `test_hodge_identifier_adapter.py`.

**Interfaces:** `build_identified_hodge_case(source_path, trusted_source_sha256, omit_identifiers=False)` returns case and derived ledger; `identity_history_verifier(source_path, trusted_source_sha256)` returns replay closure. CLI `hodge` generates ledger, case and receipt; CLI `replay` recomputes both.

- [ ] Write failing tests for a four-carrier `CARRY`, omitted identifier `REFUSE`, altered source and CLI replay.
- [ ] Implement the adapter without weakening the existing verifier or altering v1 test fixtures.
- [ ] Run all tests; generate deterministic example ledger/case/receipts.
- [ ] Fresh extract the versioned ZIP and run complete tests and both replays.

### Task 3: Handoff

**Files:** Modify `README.md`, `INTEGRATION_ROLLOUT.md`; package ZIP.

- [ ] Document identifiers, 1,875-record non-enumeration and trust anchors.
- [ ] Verify package checksum, upload durable artifact and retrieve its metadata.
- [ ] Report exact tests and limitations; no claims of unperformed deployment.
