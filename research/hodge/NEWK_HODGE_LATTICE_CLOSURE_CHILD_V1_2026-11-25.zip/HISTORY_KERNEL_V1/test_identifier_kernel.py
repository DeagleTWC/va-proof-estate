"""Red/green checks for exact object identities and distinct source records."""

import copy
from hashlib import sha256
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from identifier_kernel import (
    canonical_row_space, issue_hodge_identifiers, replay_hodge_identifiers,
)


SOURCE = Path(__file__).resolve().parent / "hodge_parent_v3_source_receipt.json"
PIN = "7966f67398ea83bbb8e4ec88e57f7307014148a0bbf8fdb37af7924f7e9d2d23"


def _hash(value):
    return sha256(json.dumps(value, sort_keys=True, ensure_ascii=True,
                             separators=(",", ":")).encode("utf-8")).hexdigest()


def _restamp(value):
    value["sha256"] = _hash({k: v for k, v in value.items() if k != "sha256"})


class IdentifierKernelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = json.loads(SOURCE.read_text(encoding="utf-8"))

    def test_exact_row_operations_share_geometric_identifier(self):
        first = [[1, 0, -1], [0, 1, -1]]
        equivalent = [[0, 2, -2], [-3, 0, 3]]
        self.assertEqual(canonical_row_space(first, 3),
                         canonical_row_space(equivalent, 3))
        self.assertNotEqual(canonical_row_space(first, 3),
                            canonical_row_space([[1, 0, -1], [0, 1, 1]], 3))

    def test_parent_and_pinned_generator_issue_all_exact_source_backed_ids(self):
        result = issue_hodge_identifiers(self.source, PIN)
        self.assertEqual(result["gate"], "ISSUE")
        self.assertEqual(result["issued_basis_objects"], 10)
        self.assertEqual(len(result["objects"]), 10)
        self.assertEqual({o["alias"] for o in result["objects"]},
                         {"H", "L1", "L2", "L3", "L4", "L5", "L6", "L7", "L8", "L9"})
        self.assertEqual(result["generated_planes_claimed"], 1875)
        self.assertEqual(result["generated_planes_individually_identified"], 1875)
        self.assertEqual(len(result["generated_planes"]), 1875)
        self.assertEqual(len({p["object_id"] for p in result["generated_planes"]}), 1875)
        self.assertEqual(result["generated_planes"][0]["pairs"],
                         [[0, 1, 1], [2, 3, 1], [4, 5, 1]])
        # Captured by running _planes(5) from the SHA-pinned original source.
        self.assertEqual(_hash([p["pairs"] for p in result["generated_planes"]]),
                         "4ef4093b9dc3ed436985419ca642cb9359cddf78c5d78d99673709a938adcf20")
        self.assertIn(result["objects"][1]["object_id"],
                      {p["object_id"] for p in result["generated_planes"]})
        self.assertTrue(result["objects"][0]["object_id"].startswith("VA:CLASS:"))
        self.assertEqual(result["objects"][0]["identity_level"], "SYMBOLIC_CLASS")
        self.assertTrue(all(o["record_id"].startswith("VA:REC:")
                            for o in result["objects"]))
        self.assertEqual(len({o["object_id"] for o in result["objects"]}), 10)
        self.assertTrue(replay_hodge_identifiers(result, self.source, PIN))

    def test_modified_generator_bytes_refuse_instead_of_guessing_plane_ids(self):
        generator = SOURCE.parent / "pinned_fermat_family_regenerator.py"
        with TemporaryDirectory() as temp:
            altered = Path(temp) / "not-the-frozen-generator.py"
            altered.write_bytes(generator.read_bytes() + b"\n# altered\n")
            receipt = issue_hodge_identifiers(
                self.source, PIN, generator_path=altered)
            self.assertEqual(receipt["gate"], "REFUSE")
            self.assertEqual(receipt["generated_planes_individually_identified"], 0)

    def test_identical_source_yields_identical_receipt(self):
        self.assertEqual(issue_hodge_identifiers(self.source, PIN),
                         issue_hodge_identifiers(copy.deepcopy(self.source), PIN))

    def test_rehashed_parent_with_wrong_independent_anchor_refuses(self):
        tampered = copy.deepcopy(self.source)
        tampered["status"] = "UNRESTRICTED_PROOF"
        _restamp(tampered)
        self.assertEqual(issue_hodge_identifiers(tampered, PIN)["gate"], "REFUSE")

    def test_duplicate_aliases_refused_even_if_new_source_anchor_given(self):
        changed = copy.deepcopy(self.source)
        changed["edge_readings"]["cycles"][2]["id"] = "L1"
        _restamp(changed["edge_readings"])
        _restamp(changed)
        result = issue_hodge_identifiers(changed, changed["sha256"])
        self.assertEqual(result["gate"], "REFUSE")
        self.assertFalse(result["invariants"]["I3_unique_ids"])

    def test_malformed_rank_or_float_in_vectors_refuses(self):
        changed = copy.deepcopy(self.source)
        changed["edge_readings"]["cycles"][1]["basis_vectors"][0][0] = 1.5
        _restamp(changed["edge_readings"])
        _restamp(changed)
        self.assertEqual(issue_hodge_identifiers(changed, changed["sha256"])["gate"],
                         "REFUSE")

    def test_invalid_claimed_source_hash_type_returns_refusal_receipt(self):
        malformed = copy.deepcopy(self.source)
        malformed["sha256"] = 1.5
        receipt = issue_hodge_identifiers(malformed, PIN)
        self.assertEqual(receipt["gate"], "REFUSE")
        self.assertIsNone(receipt["source_sha256"])

    def test_rehashed_false_ledger_verdict_replay_rejects(self):
        good = issue_hodge_identifiers(self.source, PIN)
        forged = copy.deepcopy(good)
        forged["gate"] = "REFUSE"
        _restamp(forged)
        self.assertFalse(replay_hodge_identifiers(forged, self.source, PIN))


if __name__ == "__main__":
    unittest.main()
