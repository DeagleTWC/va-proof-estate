#!/usr/bin/env python3
"""Exact V.A. child identifier kernel: object identity != source-record identity.

This public-safe portable reference never authorizes a consequence, verifies
underlying geometry, invents unlisted elements or authenticates a person.
"""

from fractions import Fraction
from hashlib import sha256
from itertools import product
from pathlib import Path
import re

from history_kernel import _check_exact, _digest, _stamped, _valid_stamp


SCHEMA = "VA_NEWK_EXACT_IDENTIFIER_CHILD_V1"
INVARIANTS = (
    "I1_source_custody", "I2_exact_object_normal_form", "I3_unique_ids",
    "I4_declared_basis_complete", "I5_provenance_linked",
)
_RATIONAL = re.compile(r"^-?(?:0|[1-9][0-9]*)(?:/[1-9][0-9]*)?$")


def _fraction(value):
    if type(value) is int:
        return Fraction(value)
    if type(value) is str and _RATIONAL.fullmatch(value):
        return Fraction(value)
    raise ValueError("NONEXACT_RATIONAL_COORDINATE")


def canonical_row_space(rows, ambient_columns):
    """Exact rational RREF, invariant under invertible changes of row basis."""
    if (type(ambient_columns) is not int or ambient_columns < 1 or
            not isinstance(rows, list) or not rows):
        raise ValueError("INVALID_PROJECTIVE_ROW_SPACE")
    if any(not isinstance(row, list) or len(row) != ambient_columns for row in rows):
        raise ValueError("INVALID_PROJECTIVE_ROW_SHAPE")
    matrix = [[_fraction(value) for value in row] for row in rows]
    pivot_row = 0
    for column in range(ambient_columns):
        at = next((j for j in range(pivot_row, len(matrix))
                   if matrix[j][column] != 0), None)
        if at is None:
            continue
        matrix[pivot_row], matrix[at] = matrix[at], matrix[pivot_row]
        pivot = matrix[pivot_row][column]
        matrix[pivot_row] = [x / pivot for x in matrix[pivot_row]]
        for j in range(len(matrix)):
            if j != pivot_row:
                factor = matrix[j][column]
                matrix[j] = [a - factor * b for a, b in
                             zip(matrix[j], matrix[pivot_row])]
        pivot_row += 1
        if pivot_row == len(matrix):
            break
    if pivot_row != len(matrix):
        raise ValueError("DEPENDENT_BASIS_VECTORS")
    return [[str(x.numerator) if x.denominator == 1
             else f"{x.numerator}/{x.denominator}" for x in row]
            for row in matrix]


def _id(kind, body):
    return "VA:" + kind + ":" + _digest({"domain": SCHEMA, "kind": kind,
                                          "body": body})


def _object_record(descriptor, geometry, source_sha256, ambient_columns):
    alias = descriptor["id"]
    if type(alias) is not str or not alias.strip():
        raise ValueError("MISSING_OBJECT_ALIAS")
    kind = descriptor["kind"]
    if descriptor["codimension"] != 2:
        raise ValueError("UNSUPPORTED_CODIMENSION")
    if kind == "HYPERPLANE_POWER":
        if (descriptor.get("construction") != "intersection_of_2_hyperplanes"
                or "basis_vectors" in descriptor):
            raise ValueError("UNSUPPORTED_SYMBOLIC_CLASS")
        level = "SYMBOLIC_CLASS"
        normal_form = {"kind": "HYPERPLANE_POWER", "power": 2}
        obj_id = _id("CLASS", {"geometry": geometry, "form": normal_form})
    elif kind == "CONTAINED_LINEAR_SUBSPACE":
        if (descriptor.get("construction") != "projective_row_span_of_listed_vectors"
                or descriptor.get("projective_dimension") != 2
                or descriptor.get("verified_polynomial_restriction") != "ZERO"):
            raise ValueError("MALFORMED_SOURCE_CYCLE_DESCRIPTOR")
        rows = descriptor["basis_vectors"]
        if not isinstance(rows, list) or len(rows) != 3:
            raise ValueError("EXPECTED_THREE_INDEPENDENT_ROW_VECTORS")
        level = "EXACT_ROW_SPACE"
        normal_form = {"kind": "PROJECTIVE_PLANE", "rref":
                       canonical_row_space(rows, ambient_columns)}
        obj_id = _id("OBJECT", {"geometry": geometry, "form": normal_form})
    else:
        raise ValueError("UNRECOGNIZED_CYCLE_CONSTRUCTION")
    record_id = _id("REC", {"source_sha256": source_sha256,
                             "descriptor": descriptor, "object_id": obj_id})
    return {"alias": alias, "kind": kind, "identity_level": level,
            "object_id": obj_id, "record_id": record_id,
            "normal_form": normal_form,
            "descriptor_sha256": _digest(descriptor)}


def _perfect_matchings(nodes):
    """Exact ordered source recurrence; never enumerate by a declared count."""
    if not nodes:
        yield ()
        return
    first = nodes[0]
    for i in range(1, len(nodes)):
        second = nodes[i]
        rest = nodes[1:i] + nodes[i + 1:]
        for tail in _perfect_matchings(rest):
            yield ((first, second),) + tail


def _generated_fermat_planes(degree, ambient_columns, geometry, source_sha256,
                              generator_sha256):
    """Enumerate the pinned rule: perfect matchings × odd ζ_(2d) exponents."""
    if (type(degree) is not int or degree < 2 or ambient_columns != 6):
        raise ValueError("UNSUPPORTED_GENERATOR_DOMAIN")
    planes = []
    for matching in _perfect_matchings(tuple(range(ambient_columns))):
        for roots in product(range(1, 2 * degree, 2), repeat=len(matching)):
            pairs = [[i, j, root] for (i, j), root in zip(matching, roots)]
            if all(root == degree for root in roots):
                # ζ_(2d)^d = -1, so these are exact rational row-space planes.
                rows = []
                for i, j in matching:
                    row = [0] * ambient_columns
                    row[i], row[j] = 1, -1
                    rows.append(row)
                form = {"kind": "PROJECTIVE_PLANE",
                        "rref": canonical_row_space(rows, ambient_columns)}
            else:
                form = {"kind": "CYCLOTOMIC_FERMAT_PAIRING_PLANE",
                        "root_order": 2 * degree, "pairs": pairs}
            object_id = _id("OBJECT", {"geometry": geometry, "form": form})
            record_id = _id("REC", {
                "source_sha256": source_sha256,
                "generator_sha256": generator_sha256,
                "pairs": pairs, "object_id": object_id})
            planes.append({"index": len(planes), "pairs": pairs,
                           "identity_level": "EXACT_CYCLOTOMIC_CONSTRUCTION",
                           "object_id": object_id, "record_id": record_id})
    return planes


def issue_hodge_identifiers(source, trusted_source_sha256, *, generator_path=None):
    """Issue exact basis and source-generator planes under independent custody.

    REFUSE is a deterministic receipt. The declared generated-plane count is
    compared with independent exact regeneration, never used to mint IDs.
    """
    invariants = dict.fromkeys(INVARIANTS, False)
    output = {"schema": SCHEMA, "gate": "REFUSE", "invariants": invariants,
              "source_sha256": (source.get("sha256") if isinstance(source, dict)
                                and type(source.get("sha256")) is str else None),
              "source_id": None, "edge_id": None,
              "ledger_id": None, "objects": [], "issued_basis_objects": 0,
              "generated_planes": [],
              "generated_planes_claimed": None,
              "generated_planes_individually_identified": 0,
              "external_hash_refs_only": [],
              "underlying_geometry_proved_by_identifiers": False}
    try:
        _check_exact(source)
        if (not isinstance(source, dict)
                or not _valid_stamp(source)
                or type(trusted_source_sha256) is not str
                or source["sha256"] != trusted_source_sha256):
            return _stamped(output)
        invariants["I1_source_custody"] = True
        edge = source["edge_readings"]
        if not _valid_stamp(edge):
            return _stamped(output)
        geometry = source["input"]["geometry"]
        ambient_columns = edge["ambient_projective_dimension"] + 1
        if (type(ambient_columns) is not int or ambient_columns < 1
                or geometry["kind"] != "SMOOTH_PROJECTIVE_HYPERSURFACE"
                or edge["input"]["ambient_variables"] != ambient_columns):
            return _stamped(output)
        geometry_key = _digest({"scope": "DECLARED_X", "geometry": geometry})
        if generator_path is None:
            generator_path = Path(__file__).resolve().parent / "pinned_fermat_family_regenerator.py"
        generator_sha256 = sha256(Path(generator_path).read_bytes()).hexdigest()
        if generator_sha256 != source["source_custody"]["fermat_family_regenerator.py"]:
            return _stamped(output)
        descriptors = edge["cycles"]
        if not isinstance(descriptors, list) or not descriptors:
            return _stamped(output)
        records = [_object_record(c, geometry_key, source["sha256"],
                                  ambient_columns) for c in descriptors]
        planes = _generated_fermat_planes(edge["degree"], ambient_columns,
                                          geometry_key, source["sha256"],
                                          generator_sha256)
        invariants["I2_exact_object_normal_form"] = True
        aliases = [c["alias"] for c in records]
        object_ids = [c["object_id"] for c in records]
        record_ids = [c["record_id"] for c in records]
        generated_ids = [p["object_id"] for p in planes]
        invariants["I3_unique_ids"] = (
            len(set(aliases)) == len(aliases)
            and len(set(object_ids)) == len(object_ids)
            and len(set(record_ids)) == len(record_ids)
            and len(set(generated_ids)) == len(planes))
        invariants["I4_declared_basis_complete"] = (
            edge["basis_cycle_ids"] == aliases
            and type(source["initial_declared_cycle_rank"]) is int
            and source["initial_declared_cycle_rank"] == len(records)
            and edge["discovered_linear_cycles"] == sum(
                r["identity_level"] == "EXACT_ROW_SPACE" for r in records))
        passes = source["regeneration_passes"]
        invariants["I5_provenance_linked"] = (
            isinstance(passes, list) and len(passes) >= 2
            and passes[0]["source_receipt_sha256"] == edge["sha256"]
            and isinstance(passes[-1]["generated_geometric_planes"], int)
            and type(passes[-1]["generated_geometric_planes"]) is int
            and passes[-1]["generated_geometric_planes"] == len(planes))
        if not all(invariants.values()):
            return _stamped(output)
        output.update({
            "gate": "ISSUE", "source_id": "VA:SOURCE:" + source["sha256"],
            "edge_id": "VA:EDGE:" + edge["sha256"],
            "ledger_id": _id("LEDGER", {"source_sha256": source["sha256"],
                                        "generator_sha256": generator_sha256,
                                        "records": records,
                                        "generated_planes": planes}),
            "objects": records, "issued_basis_objects": len(records),
            "generated_planes": planes,
            "generated_planes_claimed": passes[-1]["generated_geometric_planes"],
            "generated_planes_individually_identified": len(planes),
            "external_hash_refs_only": [
                {"kind": "RATIONAL_CHARACTER", "sha256": edge["rational_character_receipt_sha256"]},
                *({"kind": "REGENERATION_SOURCE", "sha256": p["source_receipt_sha256"]}
                  for p in passes[1:]),
            ],
        })
    except (OSError, KeyError, TypeError, ValueError, ArithmeticError,
            IndexError, AttributeError):
        return _stamped(output)
    return _stamped(output)


def replay_hodge_identifiers(receipt, source, trusted_source_sha256):
    """Recompute entire issuance, not just the submitted result digest."""
    try:
        return (_valid_stamp(receipt)
                and receipt == issue_hodge_identifiers(source, trusted_source_sha256))
    except (KeyError, ValueError, TypeError):
        return False
