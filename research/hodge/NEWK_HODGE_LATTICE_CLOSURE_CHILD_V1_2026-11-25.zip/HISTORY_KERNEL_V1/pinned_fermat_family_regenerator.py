#!/usr/bin/env python3
"""Single learned Fermat-cycle generator for degrees 2..5 in projective P5.

One formula derives all plane witnesses, intersection products and Hodge
dimensions. Crucially, failure to span the *complex* H22 space does not
establish a deficit among *rational* Hodge classes. No false promotion.
"""

import argparse
from hashlib import sha256
from itertools import product
import json
from pathlib import Path

import numpy as np

from fermat_cubic_cycle_lattice import _perfect_matchings
from fermat_rational_character_kernel import (FermatRationalCharacterKernel,
                                             replay_character_receipt)
from smooth_hypersurface_edge import SmoothHypersurfaceEdge, replay_smooth_edge


SCHEMA = "HODGE_FERMAT_REGENERATED_DEGREE_RULE_TRUE_ZERO"
PRIME = 1009


def stamp(body):
    data = json.dumps(body, sort_keys=True, ensure_ascii=True,
                      separators=(",", ":"), allow_nan=False).encode("utf8")
    return {**body, "sha256": sha256(data).hexdigest()}


def _planes(degree):
    # The odd powers of primitive ζ_(2d) have d-th power -1.
    return tuple(tuple((i, j, root) for (i, j), root in zip(m, roots))
                 for m in _perfect_matchings(tuple(range(6)))
                 for roots in product(range(1, 2 * degree, 2), repeat=3))


def _intersection_dimension(left, right, degree):
    modulus = 2 * degree
    parent = list(range(6))
    weight = [0] * 6
    bad = [False] * 6

    def find(i):
        if parent[i] == i:
            return i, 0
        r, val = find(parent[i])
        weight[i] = (weight[i] + val) % modulus
        parent[i] = r
        return r, weight[i]

    for i, j, k in left + right:
        ri, wi = find(i)
        rj, wj = find(j)
        if ri == rj:
            if (wi - k - wj) % modulus:
                bad[ri] = True
        else:
            parent[ri] = rj
            weight[ri] = (k + wj - wi) % modulus
            bad[rj] = bad[rj] or bad[ri]
    return sum(find(i)[0] == i and not bad[i] for i in range(6))


def _select_independent_planes(planes, degree, target):
    # Every pairing is an exact integer geometric intersection product:
    # disjoint=0, transverse point=1, excess line=2-d, self=d²-3d+3.
    pairing_by_dimension = (0, 1, 2 - degree, degree * degree - 3 * degree + 3)
    selected = []
    inverse = np.empty((0, 0), dtype=np.int64)
    determinant_mod = 1
    considered = 0
    for candidate in range(len(planes)):
        considered += 1
        v = np.fromiter((pairing_by_dimension[_intersection_dimension(
            planes[candidate], planes[k], degree)] % PRIME for k in selected),
            dtype=np.int64, count=len(selected))
        z = inverse.dot(v) % PRIME
        schur = (pairing_by_dimension[3] - int(v.dot(z))) % PRIME
        if not schur:
            continue
        inv_s = pow(int(schur), -1, PRIME)
        r = len(selected)
        next_inverse = np.empty((r + 1, r + 1), dtype=np.int64)
        next_inverse[:r, :r] = (inverse + np.outer(z, z) * inv_s) % PRIME
        next_inverse[:r, r] = next_inverse[r, :r] = (-z * inv_s) % PRIME
        next_inverse[r, r] = inv_s
        inverse = next_inverse
        selected.append(candidate)
        determinant_mod = determinant_mod * schur % PRIME
        if len(selected) == target:
            break
    return selected, determinant_mod, considered


def _geometry(degree):
    terms = [{"coefficient": "1", "exponents": [degree if i == j else 0
                                         for i in range(6)]} for j in range(6)]
    return SmoothHypersurfaceEdge().examine({"terms": terms})


class FermatFamilyRegenerator:
    def examine(self, degree):
        if type(degree) is not int:
            raise TypeError("Degree must be an exact integer")
        if not 2 <= degree <= 5:
            raise ValueError("The current source proves geometry for 2 <= degree <= 5")
        host = _geometry(degree)
        if (not replay_smooth_edge(host) or not host["smooth_projective_certified"]):
            raise AssertionError("Source hypersurface not certified smooth")
        complex_h22 = host["hodge_complex_dimensions"]["h22"]
        # Pass 1: derive rational Hodge dimension from all cyclotomic
        # conjugates, rather than treating the complex H22 rank as rational.
        rational = FermatRationalCharacterKernel().examine(degree)
        if (not replay_character_receipt(rational)
                or rational["complex_h22_dimension"] != complex_h22):
            raise AssertionError("Rational character and Jacobian Hodge census disagree")
        rational_hodge_rank = rational["rational_hodge_dimension"]
        planes = _planes(degree)
        # Pass 2: compare *existing geometric planes* with the now measured
        # rational Hodge rank; no child invented to fill a complex-only gap.
        selected, determinant, considered = _select_independent_planes(
            planes, degree, rational_hodge_rank)
        if determinant == 0 or len(selected) > rational_hodge_rank:
            raise AssertionError("Inconsistent intersection-rank certificate")
        complete = len(selected) == rational_hodge_rank
        return stamp({
            "schema": SCHEMA,
            "question": "RATIONAL_HODGE_SPAN_ON_FERMAT_FOURFOLD",
            "geometry": f"sum(x_i^{degree}, i=0..5)=0 in P5(C)",
            "degree": degree, "codimension": 2,
            "smoothness_source_receipt_sha256": host["sha256"],
            "perfect_matchings": 15, "generated_planes": len(planes),
            "plane_pair_self_intersection": degree * degree - 3 * degree + 3,
            "plane_pair_line_intersection": 2 - degree,
            "complex_h22_dimension": complex_h22,
            "rational_character_source_receipt_sha256": rational["sha256"],
            "galois_stable_primitive_hodge_characters": rational["rational_primitive_characters"],
            "rational_hodge_character_orbits": rational["galois_orbit_count"],
            "pair_eligible_rational_characters": rational["pair_eligible_rational_primitive_characters"],
            "unpaired_rational_characters": rational["unpaired_rational_primitive_characters"],
            "independent_quintic_closed_form_verified": (
                rational["closed_form_agrees_with_enumeration"] if degree == 5 else None),
            "certified_algebraic_rank_lower_bound": len(selected),
            "witness_plane_indices": selected,
            "candidate_planes_considered": considered,
            "determinant_mod_1009": determinant,
            "rational_hodge_dimension": rational_hodge_rank,
            "rational_cycle_deficit": 0 if complete else None,
            "complex_h22_not_in_selected_plane_span": complex_h22 - len(selected),
            "status": ("EXACT_CYCLE_SPAN" if complete
                       else "RATIONAL_HODGE_COMPLETENESS_UNDETERMINED"),
            "true_zero_rational_hodge_quotient": complete,
            "hodge_counterexample_found": False,
            "unrestricted_hodge_proof": False,
            "invariant_boundary": (
                "A nonzero modular minor proves rational algebraic independence. "
                "The cyclotomic character census (using a named Fermat "
                "cohomology theorem) computes rational Hodge rank. "
                "An algebraic Gram lower bound reaching that rank proves "
                "rational Hodge spanning; the complex complement alone "
                "never measures an unfilled rational Hodge class."),
        })


def replay_family_receipt(receipt):
    if not isinstance(receipt, dict) or not isinstance(receipt.get("sha256"), str):
        return False
    try:
        body = {k: v for k, v in receipt.items() if k != "sha256"}
        return stamp(body) == receipt and FermatFamilyRegenerator().examine(
            receipt["degree"]) == receipt
    except (TypeError, ValueError, KeyError, AssertionError):
        return False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--degree", type=int, help="Exact Fermat degree, 2 through 5")
    action.add_argument("--replay", type=Path, help="Recompute and verify a receipt")
    parser.add_argument("--output", type=Path, help="Write the generated JSON receipt")
    args = parser.parse_args()

    if args.replay is not None:
        receipt = json.loads(args.replay.read_text(encoding="utf8"))
        if replay_family_receipt(receipt):
            print("REPLAY_OK", receipt["status"])
            return 0
        print("REPLAY_REJECTED")
        return 1

    receipt = FermatFamilyRegenerator().examine(args.degree)
    encoded = json.dumps(receipt, sort_keys=True, indent=2) + "\n"
    if args.output is None:
        print(encoded, end="")
    else:
        args.output.write_text(encoded, encoding="utf8")
        print("RECEIPT_WRITTEN", str(args.output))
    print("RATIONAL_HODGE_GATE", receipt["status"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
