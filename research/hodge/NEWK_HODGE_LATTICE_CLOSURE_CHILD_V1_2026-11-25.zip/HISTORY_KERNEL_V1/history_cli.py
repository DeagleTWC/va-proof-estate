#!/usr/bin/env python3
"""Portable, before-action History Kernel gate; non-CARRY exits nonzero."""

import argparse
import json
import os
from pathlib import Path
import sys
import tempfile

from history_kernel import evaluate, replay
from history_verifiers import verify_rank_closure
from hodge_history_adapter import build_hodge_case


VERIFIERS = {"HODGE_RANK_CLOSURE_V1": verify_rank_closure}


def _read(path):
    return json.loads(Path(path).read_text(encoding="utf8"))


def _write_atomic(path, value):
    target = Path(path).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf8", suffix=".tmp",
                                         prefix=target.name + ".", dir=target.parent,
                                         delete=False) as handle:
            tmp_path = Path(handle.name)
            json.dump(value, handle, sort_keys=True, indent=2, ensure_ascii=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_path, target)
    finally:
        if tmp_path is not None and tmp_path.exists():
            tmp_path.unlink()


def main(argv=None):
    parser = argparse.ArgumentParser(description="History Continuity Kernel: carry, reexamine, refuse")
    sub = parser.add_subparsers(dest="action", required=True)
    run = sub.add_parser("run", help="evaluate before a proposed consequence")
    run.add_argument("--case", required=True)
    run.add_argument("--output", required=True)
    run.add_argument("--trusted-contract-sha", required=True,
                     help="frozen SHA-256 supplied separately by the hosting custodian")
    run.add_argument("--trusted-tip-sha", help="externally anchored prior-history tip")
    check = sub.add_parser("replay", help="independently recompute a preserved receipt")
    check.add_argument("--case", required=True)
    check.add_argument("--receipt", required=True)
    check.add_argument("--trusted-contract-sha", required=True)
    check.add_argument("--trusted-tip-sha")
    example = sub.add_parser("hodge-example", help="bind the frozen Hodge v3 source")
    example.add_argument("--source", required=True)
    example.add_argument("--expected-source-sha", required=True)
    example.add_argument("--output", required=True)
    example.add_argument("--omit-edge", action="store_true")
    args = parser.parse_args(argv)
    if args.action == "hodge-example":
        case = build_hodge_case(args.source,
                                trusted_source_sha256=args.expected_source_sha,
                                omit_edge=args.omit_edge)
        _write_atomic(args.output, case)
        print("HODGE_HISTORY_CASE_READY")
        return 0
    case = _read(args.case)
    inputs = {"contract": case["contract"], "evidence": case["evidence"],
              "prior": case.get("prior"),
              "trusted_tip_sha256": args.trusted_tip_sha,
              "trusted_contract_sha256": args.trusted_contract_sha,
              "consumption_verifier": VERIFIERS.get(case.get("consumption_verifier_id"))}
    if args.action == "run":
        receipt = evaluate(**inputs, request=case["request"])
        _write_atomic(args.output, receipt)
        print("HISTORY_GATE", receipt["gate"])
        return {"CARRY": 0, "REEXAMINE": 2, "REFUSE": 3}[receipt["gate"]]
    valid = replay(_read(args.receipt), **inputs)
    print("REPLAY_OK" if valid else "REPLAY_REFUSED")
    return 0 if valid else 4


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, TypeError, KeyError) as exc:
        print("HISTORY_INPUT_REFUSED", type(exc).__name__, file=sys.stderr)
        sys.exit(3)
