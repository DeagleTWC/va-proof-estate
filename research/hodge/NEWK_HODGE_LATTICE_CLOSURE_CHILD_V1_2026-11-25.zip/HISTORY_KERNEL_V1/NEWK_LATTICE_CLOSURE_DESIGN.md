# Exact Lattice Closure Child v1 — Frozen New K Hodge Lineage

**Author:** Terry Allen Snyder / V.A. Proof Estate. **Date:** 25 November 2026.

## Question

Does the frozen source-derived quintic plane lattice give an exact, fully
identified, Galois-organized intersection witness of the already recorded
401-dimensional rational Hodge span on the **declared Fermat quintic**?

## One kernel / five invariants / one gate

1. **I1 source custody:** externally frozen v3 source and identifier receipts,
   plus the generator and 401-index regeneration receipt, replay byte-exactly.
2. **I2 identity closure:** the 1,875 generated object IDs match independently
   regenerated exact pairing/exponent triples in their original order.
3. **I3 Galois closure:** multiplication of exponents by units modulo ten
   partitions all 1,875 planes into exact cyclotomic-conjugacy orbits.
4. **I4 intersection witness:** exact integer projective-plane intersection
   pairings generate the selected 401×401 Gram matrix with nonzero determinant
   437 modulo 1009.
5. **I5 rational closure:** 401 selected, independent algebraic plane classes
   match the separately frozen rational Hodge dimension 401 for this X.

Gate: **CARRY** only when all five invariants hold and conditions are unchanged;
**REEXAMINE** for a changed condition with otherwise valid evidence;
**REFUSE** for inconsistent/unauthenticated evidence. No formed consequence or
mathematical claim is promoted automatically.

## Exactness and boundary

- Matchings and odd root exponents are exact finite structures; no fitted
  coefficients or tolerances.
- Intersection values are determined by geometry: 0 for empty, 1 for point,
  2−5=−3 for line, and 5²−3·5+3=13 for self-pairing.
- A nonzero integer Gram determinant modulo 1009 proves a nonzero determinant
  over Q for the chosen 401 classes. Equality to the rational dimension uses
  the **frozen Fermat rational-character census** rather than a new universal
  cohomology theorem.
- Recompute the complete matrix/orbit map and write exact deterministic
  receipts. Never substitute an asserted label or source count for measurement.
- Does **not** authenticate protected GEN1056, prove arbitrary all-X Hodge,
  certify physical harmonics, or overwrite the published identifier child.
