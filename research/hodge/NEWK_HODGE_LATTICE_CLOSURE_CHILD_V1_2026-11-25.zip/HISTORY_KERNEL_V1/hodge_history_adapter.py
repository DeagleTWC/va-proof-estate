"""Public-safe Hodge v3 example for the portable History Continuity Kernel.

This adapter verifies the pinned, self-hashed parent receipt and binds its
edge/rational/cycle evidence. The Hodge parent remains responsible for
mathematical proof and independent receipt replay; no protected GEN is read.
"""

import json
from pathlib import Path

from history_kernel import _digest, create_contract, make_evidence


def build_hodge_case(source_path, *, trusted_source_sha256, omit_edge=False):
    if type(trusted_source_sha256) is not str or len(trusted_source_sha256) != 64:
        raise ValueError("A frozen 64-character parent receipt hash is required")
    source = json.loads(Path(source_path).read_text(encoding="utf-8"))
    actual = _digest({k: v for k, v in source.items() if k != "sha256"})
    if source.get("sha256") != actual or actual != trusted_source_sha256:
        raise ValueError("HODGE_SOURCE_RECEIPT_CUSTODY_MISMATCH")
    edge = source["edge_readings"]
    if (edge.get("sha256") != _digest({k: v for k, v in edge.items()
                                       if k != "sha256"})
            or not source["declared_x_cycle_span_closed"]):
        raise ValueError("HODGE_EDGE_SOURCE_REPLAY_OR_SPAN_MISSING")
    passes = source["regeneration_passes"]
    if not passes or passes[0]["source_receipt_sha256"] != edge["sha256"]:
        raise ValueError("HODGE_EDGE_REGENERATION_CHAIN_MISMATCH")

    evidence = [
        make_evidence("edge", "EDGE_LATTICE", "DECLARED_X", {
            "edge_receipt_sha256": edge["sha256"],
            "initial_lattice_rank": source["initial_declared_cycle_rank"],
            "basis_ids": edge["basis_cycle_ids"],
        }),
        make_evidence("rational", "RATIONAL_CLASS", "DECLARED_X", {
            "rational_hodge_rank": source["rational_hodge_rank_for_declared_x"],
            "character_receipt_sha256": edge["rational_character_receipt_sha256"],
        }),
        make_evidence("cycles", "CYCLE_CONSTRUCTION", "DECLARED_X", {
            "cycle_rank": source["final_declared_cycle_rank"],
            "source_receipts": [p["source_receipt_sha256"] for p in passes],
            "generated_geometric_planes": passes[-1].get("generated_geometric_planes"),
        }),
    ]
    contract = create_contract(
        stream_id="HODGE_PARENT_V3", question=source["question"],
        source_sha256=actual, scope="DECLARED_X", evidence=evidence)
    request = {
        "event_id": "hodge-parent-v3-" + actual[:12],
        "sequence": 0, "previous_receipt_sha256": None,
        "stream_id": "HODGE_PARENT_V3", "question": source["question"],
        "source_sha256": actual, "scope": "DECLARED_X",
        "conditions": {
            "equation_sha256": _digest(source["input"]["geometry"]["equation"]),
            "parent_schema": source["schema"],
        },
        "consumed_evidence_ids": (["rational", "cycles"] if omit_edge
                                  else ["edge", "rational", "cycles"]),
    }
    return {"contract": contract, "evidence": evidence, "request": request,
            "consumption_verifier_id": "HODGE_RANK_CLOSURE_V1",
            "trusted_contract_sha256": contract["sha256"],
            "trusted_source_sha256": trusted_source_sha256}
