"""Real Hodge v3 receipt must enter the history gate as consumed evidence."""

from pathlib import Path
import unittest

from history_kernel import evaluate, replay
from history_verifiers import verify_rank_closure
from hodge_history_adapter import build_hodge_case


SOURCE = Path(__file__).resolve().parent / "hodge_parent_v3_source_receipt.json"
PIN = "7966f67398ea83bbb8e4ec88e57f7307014148a0bbf8fdb37af7924f7e9d2d23"


class HodgeHistoryAdapterTests(unittest.TestCase):
    def test_actual_v3_source_is_bound_and_carries(self):
        case = build_hodge_case(SOURCE, trusted_source_sha256=PIN)
        receipt = evaluate(case["contract"], case["evidence"], case["request"],
                           trusted_contract_sha256=case["trusted_contract_sha256"],
                           consumption_verifier=verify_rank_closure)
        self.assertEqual(receipt["gate"], "CARRY")
        self.assertEqual({x["kind"] for x in case["evidence"]},
                         {"EDGE_LATTICE", "RATIONAL_CLASS", "CYCLE_CONSTRUCTION"})
        self.assertTrue(replay(receipt, contract=case["contract"],
                               evidence=case["evidence"],
                               trusted_contract_sha256=case["trusted_contract_sha256"],
                               consumption_verifier=verify_rank_closure))

    def test_actual_v3_source_missing_edge_consumption_refuses(self):
        case = build_hodge_case(SOURCE, trusted_source_sha256=PIN, omit_edge=True)
        receipt = evaluate(case["contract"], case["evidence"], case["request"],
                           trusted_contract_sha256=case["trusted_contract_sha256"],
                           consumption_verifier=verify_rank_closure)
        self.assertEqual(receipt["gate"], "REFUSE")
        self.assertEqual(receipt["missing_consumed_evidence_ids"], ["edge"])

    def test_wrong_source_anchor_is_refused_before_any_history_gate(self):
        with self.assertRaises(ValueError):
            build_hodge_case(SOURCE, trusted_source_sha256="0" * 64)


if __name__ == "__main__":
    unittest.main()
