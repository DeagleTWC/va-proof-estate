#!/usr/bin/env python3
"""Rebuild Stage 79 internal chord-mediator incidence graph from Stage 72 ledger."""
import collections, hashlib, json, pathlib, zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]

def key(x): return (int(x[0]),)+tuple(int(v) for v in x[1])
def components(adj):
    seen=set(); out=[]
    for s in adj:
        if s in seen: continue
        q=[s]; seen.add(s); comp=[]
        while q:
            v=q.pop(); comp.append(v)
            for w in adj[v]:
                if w not in seen: seen.add(w); q.append(w)
        out.append(comp)
    return out

def distances(adj, source):
    d={source:0}; q=collections.deque([source])
    while q:
        v=q.popleft()
        for w in adj[v]:
            if w not in d: d[w]=d[v]+1; q.append(w)
    return d

def tarjan(adj):
    timer=0; tin={}; low={}; parent={}; arts=set(); bridges=[]
    def dfs(v):
        nonlocal timer
        timer+=1; tin[v]=low[v]=timer; children=0
        for w in adj[v]:
            if w==parent.get(v): continue
            if w in tin: low[v]=min(low[v],tin[w])
            else:
                parent[w]=v; children+=1; dfs(w); low[v]=min(low[v],low[w])
                if v in parent and low[w]>=tin[v]: arts.add(v)
                if low[w]>tin[v]: bridges.append(tuple(sorted((v,w),key=repr)))
        if v not in parent and children>1: arts.add(v)
    for v in adj:
        if v not in tin: dfs(v)
    return arts,bridges

with zipfile.ZipFile(ROOT/'SOURCE_STAGE72.zip') as z:
    names=z.namelist()
    data=json.loads(z.read(next(n for n in names if n.endswith('STAGE72_MEDIATOR_LEDGER.json'))))
    summary=json.loads(z.read(next(n for n in names if n.endswith('STAGE72_RESULTS.json'))))
chords={key(c) for c in data['chords']}
internal=[m for m in data['residual_mediators'] if m['is_internal']]
assert len(chords)==125 and len(internal)==96
adj=collections.defaultdict(set)
med_degree={}
for m in internal:
    mk=('M',)+key(m['link']); cs=[key(c) for c in m['chords']]
    med_degree[mk]=len(cs); adj[mk]
    for c in cs:
        ck=('C',)+c; adj[mk].add(ck); adj[ck].add(mk)
assert sum(med_degree.values())==491
comps=components(adj)
assert len(comps)==1
all_d=[]
for v in adj: all_d.extend(distances(adj,v).values())
diameter=max(all_d)
arts,bridges=tarjan(adj)
assert diameter==11 and len(arts)==1 and len(bridges)==1
art=next(iter(arts)); bridge=bridges[0]
# Internal-mediator projection on chord vertices.
proj={('C',)+c:set() for c in chords}
for m in internal:
    cs=[('C',)+key(c) for c in m['chords']]
    for i,u in enumerate(cs): proj[u].update(cs[:i]+cs[i+1:])
edge_count=sum(map(len,proj.values()))//2
pcomps=components(proj)
pdiam=max(max(distances(proj,v).values()) for v in proj)
assert len(pcomps)==1 and edge_count==951 and pdiam==5
# Articulation removal component sizes.
adj2={v:set(ws) for v,ws in adj.items() if v!=art}
for v in adj2: adj2[v].discard(art)
removed_sizes=sorted((len(c) for c in components(adj2)),reverse=True)
assert removed_sizes==[219,1]
checks={
 'stage72_source':summary['stage']==72,
 'chords_125':len(chords)==125,
 'internal_mediators_96':len(internal)==96,
 'internal_incidences_491':sum(med_degree.values())==491,
 'bipartite_connected':len(comps)==1,
 'bipartite_diameter_11':diameter==11,
 'one_articulation_vertex':len(arts)==1,
 'one_bridge':len(bridges)==1,
 'articulation_removal_sizes_219_1':removed_sizes==[219,1],
 'chord_projection_connected':len(pcomps)==1,
 'chord_projection_edges_951':edge_count==951,
 'chord_projection_diameter_5':pdiam==5,
 'source_zip_integrity':zipfile.ZipFile(ROOT/'SOURCE_STAGE72.zip').testzip() is None,
 'parent_zip_integrity':zipfile.ZipFile(ROOT/'PARENT_STAGE78.zip').testzip() is None,
}
assert all(checks.values()),checks
out={
 'stage':79,'parent_stage':78,'source_stage':72,
 'bipartite_graph':{'chord_vertices':125,'internal_mediator_vertices':96,'total_vertices':221,'incidences':491,'components':1,'diameter':diameter,
  'mediator_degree_histogram':dict(sorted(collections.Counter(med_degree.values()).items())),
  'chord_degree_histogram':dict(sorted(collections.Counter(len(adj[('C',)+c]) for c in chords).items()))},
 'articulation':{'count':len(arts),'chord':list(art[1:]),'degree':len(adj[art]),'removal_component_sizes':removed_sizes,
  'bridge_mediator':list(next(v[1:] for v in bridge if v[0]=='M')),'bridge_chord':list(next(v[1:] for v in bridge if v[0]=='C'))},
 'chord_projection':{'vertices':len(proj),'edges':edge_count,'components':len(pcomps),'diameter':pdiam},
 'checks':checks,'passed':sum(checks.values()),'total':len(checks),
 'parent_stage78_sha256':hashlib.sha256((ROOT/'PARENT_STAGE78.zip').read_bytes()).hexdigest(),
 'source_stage72_sha256':hashlib.sha256((ROOT/'SOURCE_STAGE72.zip').read_bytes()).hexdigest(),
 'scope':'Exact combinatorial reconstruction from inherited Stage 72 ledger. Does not determine pivotal-shell fiber topology, coarea regularity, conditional probabilities, or spectral gaps.'}
(ROOT/'results'/'STAGE79_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(f"{out['passed']}/{out['total']} structural assertions passed")
print(json.dumps(out['articulation'],indent=2))
