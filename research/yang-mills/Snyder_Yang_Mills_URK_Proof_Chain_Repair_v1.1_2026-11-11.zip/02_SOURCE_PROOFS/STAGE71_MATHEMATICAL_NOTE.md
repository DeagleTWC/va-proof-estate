# Yang–Mills Mathematical Continuation — Stage 71

**Title:** Exact chord-dependent Wilson action and graph-specific influence bound  
**Date:** 10 November 2026  
**Parent:** Stage 70 — exact graph gauge quotient and flat-holonomy decomposition  
**Project:** Four-dimensional SU(2) Yang–Mills existence and mass gap  
**Disposition:** Stage 71 refines the Stage 70 induced-density representation by identifying exactly which ambient plaquette factors depend on the 125 gauge-fixed chord holonomies. The dependence is through 519 plaquettes: 288 contain one chord and 231 contain two. Each chord lies in exactly six plaquettes, and the induced log-density has a volume-independent graph-specific oscillation bound of 1038 beta and a per-chord derivative bound of 6 beta. The resulting domination estimate is explicit but exponentially weak; it does not establish Wilson-loop concentration.

## 1. Coordinates inherited from Stage 70

Work on the periodic lattice \(\Lambda=(\mathbb Z/4\mathbb Z)^4\), with the Stage 69/70 exterior graph \(G_C=(V_C,C)\). Its deterministic spanning forest has 112 tree edges and 125 chords \(J\). Tree gauge fixes every tree variable to the identity. The remaining graph variables are the ordered fundamental-cycle holonomies

\[
W=(W_e)_{e\in J}\in SU(2)^{125},
\]

modulo simultaneous conjugation on each of the two graph components.

The Stage 69 exact-component event and pivotal target face are supported entirely on internal links \(I\), disjoint from \(C\). After the tree-gauge change of variables, these conditions therefore belong to the remaining integration variables, not to the chord coordinates \(W\). This point is essential to the common-measure comparison below.

## 2. Exact chord incidence refinement

Let \(P_J\) be the set of ambient elementary plaquettes containing at least one chord edge, after tree links have been fixed to the identity. Exact enumeration from the preserved Stage 69 edge/chord lists gives:

| Chord incidence per plaquette | Number of plaquettes |
|---:|---:|
| 0 | 1017 |
| 1 | 288 |
| 2 | 231 |
| 3 or 4 | 0 |
| **At least 1** | **519** |

Each of the 125 chord edges is incident to exactly six elementary plaquettes, giving 750 chord-plaquette incidences. The 231 two-chord plaquettes define 231 edges in the direct chord-interaction graph. Its degree distribution is: degree 1: 5 chords; degree 2: 12; degree 3: 27; degree 4: 53; degree 5: 28. Thus the maximum direct interaction degree is five.

This is a statement about direct plaquette incidence only. Integrating the other lattice links can create effective correlations between chord variables that are not adjacent in this finite direct-interaction graph.

## 3. Exact induced density

Let \(q_p(U)=\tfrac12\operatorname{ReTr}U_p\in[-1,1]\). Remove the configuration-independent Wilson factor \(e^{-1536\beta}\); the remaining Gibbs weight is \(\exp(\beta\sum_p q_p)\).

Let \(d\eta_{\Gamma,c}(Y)\) denote the positive finite measure over all remaining gauge-fixed link variables, including:

- product Haar measure on the non-chord links;
- the exact six-plaquette component indicator and its 65 strict-good boundary conditions;
- the target pivotal-shell coarea measure at scalar threshold \(c\);
- all Wilson factors from plaquettes not depending on any chord variable.

Because the component and shell constraints are supported on \(I\), the measure \(d\eta_{\Gamma,c}\) is independent of \(W\). Define

\[
H_J(W,Y)=\sum_{p\in P_J}q_p(W,Y),\qquad
R_{L,\beta,\Gamma,c}(W)=\int e^{\beta H_J(W,Y)}\,d\eta_{\Gamma,c}(Y).
\]

Then the marginal law of the chord tuple under the exact-component pivotal-shell Wilson measure is exactly

\[
\boxed{d\bar\nu_{L,\beta,\Gamma,c}(W)=
\frac{R_{L,\beta,\Gamma,c}(W)}
{\int_{SU(2)^{125}}R_{L,\beta,\Gamma,c}(V)\,dV}\,dW.}
\]

The density is invariant under the two residual simultaneous component conjugations. No factorization of \(R\) is asserted.

## 4. Theorem 71.1 — Chord-specific log-oscillation bound

For any two chord assignments \(W,W'\), every normalized plaquette scalar belongs to \([-1,1]\). Therefore

\[
|H_J(W,Y)-H_J(W',Y)|\leq 2|P_J|=1038
\]

for every fixed \(Y\). Exponentiating and integrating against the same positive measure \(d\eta_{\Gamma,c}\) gives

\[
\boxed{
 e^{-1038\beta}R(W')\leq R(W)\leq e^{1038\beta}R(W').}
\]

Equivalently, \(\operatorname{osc}(\log R)\leq1038\beta\). The constant depends on the fixed Stage 69 graph but not on the total periodic lattice volume, provided the same local incidence graph is embedded without changing its plaquette incidence and the event/shell remains supported in \(I\).

This improves Stage 70's coarse 696-plaquette bound to 519 genuinely chord-dependent plaquette factors. The 177 plaquettes in Stage 70's 696 which meet \(C\) only through tree edges become independent of \(W\) after tree gauge fixing.

## 5. Corollary 71.2 — Haar domination (explicitly weak)

Let \(dH(W)\) be product normalized Haar measure on \(SU(2)^{125}\), and let \(f=d\bar\nu/dH\). Since the ratio of the maximum and minimum of \(R\) is at most \(e^{1038\beta}\),

\[
\boxed{e^{-1038\beta}\leq f(W)\leq e^{1038\beta}.}
\]

For every measurable set \(A\),

\[
\boxed{e^{-1038\beta}H(A)\leq\bar\nu(A)\leq e^{1038\beta}H(A).}
\]

The upper bound is volume-uniform but exponentially poor at weak coupling. It does not imply concentration of the 125 Wilson loops near identity.

## 6. Theorem 71.3 — Per-chord derivative bound

A fixed chord occurs in exactly six elementary plaquettes in four dimensions. Along a unit-speed geodesic variation of that chord, each affected normalized trace has derivative of absolute value at most one. Thus \(|D_eH_J|\leq6\). Differentiation under the finite compact integral yields

\[
D_e\log R=\beta\,\mathbb E_{W}[D_eH_J],
\]

where the conditional expectation is with respect to the normalized \(Y\)-integrand at fixed \(W\). Consequently,

\[
\boxed{|D_e\log R|\leq6\beta.}
\]

For a product geodesic path \(W(t)\),

\[
|\log R(W(1))-\log R(W(0))|
\leq6\beta\sum_{e\in J}\operatorname{Length}(W_e(t)).
\]

This is a local sensitivity bound, not a decay estimate.

## 7. Theorem 71.4 — Exact second-variation identity and mediated correlations

For a smooth two-parameter family \(W(s,t)\), write \(H=H_J(W(s,t),Y)\). Differentiating the log-partition integral gives

\[
\boxed{\partial_s\partial_t\log R
=\beta\,\mathbb E_W[H_{st}]
+\beta^2\operatorname{Cov}_W(H_s,H_t).}
\]

If the chord variables varied by \(s\) and \(t\) share no plaquette, then the direct mixed derivative \(H_{st}\) is zero. The covariance term need not vanish: it records correlations transmitted through the integrated link variables \(Y\). Thus bounded direct chord degree does not by itself imply a sparse or decaying effective interaction after integrating the rest of the lattice.

## 8. Disposition and next obligation

**Established:** exact 519-factor chord dependence; incidence histogram 288/231; six plaquettes per chord; direct chord interaction graph with 231 edges and maximum degree five; induced-density disintegration; volume-independent log-oscillation bound; Haar domination; per-chord derivative bound; exact second-variation identity.

**Not established:** a useful weak-coupling upper/lower bound on \(R(W)\) that is substantially sharper than \(e^{\pm1038\beta}\); decay of the mediated covariance term; exact-sector Wilson-loop concentration; gauge-orbit collar complement decay; unconditional pivotal-flux suppression; polymer convergence; RG summability; continuum reconstruction; positive physical mass gap.

Stage 71 is a finite-graph influence refinement. It does not establish the Yang–Mills mass gap.
