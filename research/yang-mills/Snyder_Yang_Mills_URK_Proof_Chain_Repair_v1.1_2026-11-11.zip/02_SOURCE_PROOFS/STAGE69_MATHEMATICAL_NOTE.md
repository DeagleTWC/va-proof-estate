# Yang–Mills Mathematical Continuation — Stage 69

**Title:** Exact exterior-graph cycle enumeration and forced-good filling obstruction  
**Date:** 10 November 2026  
**Parent:** Stage 68 — gauge-orbit collar reduction to fundamental Wilson-loop data  
**Project:** Four-dimensional SU(2) Yang–Mills existence and mass gap  
**Disposition:** Stage 69 reconstructs the actual 237-link exterior graph from the six-plaquette component listed in Stage 49 and the Stage 67 definitions. It computes a deterministic spanning forest and all 125 fundamental cycles. It also identifies a structural incompatibility in the proposed Stage 68 filling route: the 65 plaquettes forced good by the exact-component event have all their edges in the internal link set `I`, while the collar graph `C` is disjoint from `I`. Consequently, no nonempty cycle supported entirely in `C` can be the boundary of a 2-chain made only of those forced-good faces. The graph also detects all four torus winding directions. No Wilson-loop expectation bound is obtained.

## 1. Definitions inherited from Stages 49 and 67

Work on the periodic lattice \(\Lambda=(\mathbb Z/4\mathbb Z)^4\). A positively oriented link is a pair \((\mu,x)\), from \(x\) to \(x+e_\mu\), with \(\mu\in\{1,2,3,4\}\). A positively oriented plaquette is \(P_{\mu\nu}(x)\), \(\mu<\nu\), with its four boundary links.

The exact six-plaquette component from Stage 49 is

\[
\begin{aligned}
\Gamma=\{&P_{12}(0,2,0,0),\ P_{12}(0,3,0,0),\ P_{13}(0,3,0,0),\\
&P_{14}(0,3,0,0),\ P_{14}(0,3,0,3),\ P_{13}(0,3,3,0)\}.
\end{aligned}
\]

Let \(\partial_P\Gamma\) be the set of plaquettes outside \(\Gamma\) that share at least one link with a plaquette of \(\Gamma\). The Stage 49 enumeration says \(|\Gamma|=6\), \(|\partial_P\Gamma|=66\), with one target face on the threshold and the other 65 faces strictly good.

Following Stage 67, define:

- \(I\): all links appearing in plaquettes of \(\Gamma\cup\partial_P\Gamma\);
- \(Q(I)\): all lattice plaquettes containing at least one link in \(I\);
- \(C\): all links outside \(I\) that occur in at least one plaquette of \(Q(I)\).

This is the 237-link exterior collar graph used in Stage 67–68.

## 2. Theorem 69.1 — Exact graph reconstruction

The definitions above give exactly

\[
\boxed{|\Gamma|=6,\quad |\partial_P\Gamma|=66,\quad |I|=120,\quad |Q(I)|=318,\quad |C|=237.}
\]

The undirected graph \(G_C=(V_C,C)\), with endpoints taken modulo 4, has

\[
\boxed{|V_C|=114,\qquad c_C=2.}
\]

### Proof

Enumerate all \(6\cdot4^4=1536\) positively oriented plaquettes. For each listed plaquette, construct its four canonical positively indexed links. Compute \(\partial_P\Gamma\) by testing link-set intersection with the links of \(\Gamma\). Form \(I\) as the union of the four-link boundaries of \(\Gamma\cup\partial_P\Gamma\), form \(Q(I)\) by link intersection, and form \(C\) as the union of links of \(Q(I)\) with \(I\) removed. The counts above follow from exhaustive finite enumeration. Vertices and connected components are obtained from the resulting finite undirected edge list. The reproducible enumerator is included in `verification/enumerate_stage69.py`; the complete edge and plaquette lists are in `results/STAGE69_GRAPH_ENUMERATION.json`. \(\square\)

## 3. Theorem 69.2 — Cycle rank and deterministic fundamental-cycle data

Choose the lexicographic breadth-first spanning forest specified by the included enumerator. It has

\[
|T|=112,
\qquad
J=C\setminus T,
\qquad |J|=125.
\]

Thus the cycle rank is

\[
\boxed{\beta_1(G_C)=|C|-|V_C|+c_C=237-114+2=125.}
\]

For this specified forest, the 125 fundamental cycles have:

- lengths: 59 of length 6, 46 of length 8, 10 of length 10, and 10 of length 12;
- maximum length: \(12\);
- total length: \(K_C=942\);
- 77 cycles with nonzero torus winding and 48 with zero winding.

The count 77 is specific to the chosen spanning forest; an alternative spanning forest changes the individual fundamental-cycle basis. The rank of the winding map is basis invariant and equals

\[
\boxed{\operatorname{rank}_{\mathbb Q}(\mathrm{wind}:Z_1(G_C)\to\mathbb Q^4)=4.}
\]

In particular, the cycle space of \(G_C\) detects all four independent periodic directions. Explicit fundamental cycles with winding vectors \((1,0,0,0)\), \((0,1,0,0)\), \((0,0,1,0)\), and \((0,0,0,1)\) are included in the graph-enumeration JSON.

### Proof

The cycle-rank formula for a finite graph gives 125. The enumerator builds a deterministic BFS forest, then for each chord joins that chord to the unique forest path between its endpoints. Each cycle is checked edge-by-edge for closure on the periodic lattice. Its winding vector is obtained by lifting the oriented edge path to \(\mathbb Z^4\), summing signed coordinate steps, and dividing the resulting displacement by 4. The winding-rank calculation is exact over rational arithmetic. \(\square\)

## 4. Theorem 69.3 — Forced-good plaquettes cannot fill a nonempty collar-graph cycle

Let \(F_{\rm good}\) be the 65 plaquettes in \(\partial_P\Gamma\) that the exact-component event forces strictly good (excluding the one pivotal threshold face). Then

\[
\boxed{\partial p\subset I\quad\text{for every }p\in F_{\rm good},\qquad I\cap C=\varnothing.}
\]

Therefore, for any 2-chain \(S\) supported only on \(F_{\rm good}\), its boundary is supported in \(I\). It cannot equal a nonempty 1-cycle supported entirely in \(C\):

\[
\boxed{\partial S\ne z\quad\text{for every nonzero }z\in Z_1(G_C).}
\]

### Proof

By definition, `I` contains every link of every plaquette in \(\Gamma\cup\partial_P\Gamma\), so in particular every edge of every forced-good boundary plaquette. By definition, `C` contains only links outside `I`; hence \(I\cap C=\emptyset\). The cellular boundary of any chain supported on \(F_{\rm good}\) is a sum of edges in `I`. If it were equal to a nonzero cycle whose edges all lie in `C`, its support would be contained in \(I\cap C=\emptyset\), a contradiction. \(\square\)

This is a structural correction to the proposed deterministic route in Stage 68 §5. The conditional plaquette-filling proposition there is mathematically valid as a general statement, but its hypothesis cannot be met by the 65 plaquettes forced good by this exact-component event when the loop is a nonempty fundamental cycle of the exterior-only graph `C`.

## 5. Topological consequence

The winding rank 4 means the collar graph contains cycles detecting every periodic direction of the four-torus. Their holonomies are not forced to be the identity by local flatness alone: flat connections on a torus can have nontrivial commuting global holonomies. Thus the identity-orbit collar from Stage 67 needs either (i) additional controlled plaquette data on a larger subcomplex, or (ii) a collar around the appropriate flat-holonomy moduli, with a new covariant fibre-patch transfer argument.

The current exact-component condition fixes only the 65 boundary faces as good. It does not control the second-shell plaquettes whose boundaries could involve edges of `C`.

## 6. Consequences for Stage 68

The finite-graph comparison theorem in Stage 68 remains valid. With the explicitly specified lexicographic BFS forest, its graph constants can now be instantiated as

\[
\boxed{m_C=125,\quad K_C=942,\quad \ell_{\max}=12.}
\]

Thus the deterministic comparison reads

\[
d_C^{\rm orb}(b,[1])^2\leq Q_C(b)\leq942\,d_C^{\rm orb}(b,[1])^2.
\]

The probabilistic consequence also remains valid:

\[
\nu_{\Gamma,c}((B_\varepsilon^{\rm orb})^c)
\leq\varepsilon^{-2}\sum_{e\in J}\mathbb E_{\nu_{\Gamma,c}}D_e.
\]

But Stage 69 does **not** estimate these 125 Wilson-loop expectations under the exact-component pivotal-shell exterior measure. The finite graph contains a substantial winding subspace, and the forced-good face set does not provide fillings for its collar cycles.

## 7. Required next step

A viable continuation must change one of the following inputs without conflating them:

1. Enlarge the controlled plaquette set to include a 2-complex whose faces genuinely meet the exterior graph `C`, and prove a conditional lower-bound patch for those additional constraints.
2. Replace the identity gauge-orbit collar by a collar around the flat-holonomy moduli detected by the winding map, then redo the Stage 67 fibre-patch transfer.
3. Prove the 125 exact-sector Wilson-loop expectation bounds directly under \(\nu_{\Gamma,3/5}\), without relying on deterministic filling by the 65 boundary faces.

No ordinary Wilson-measure estimate is substituted for the exact-component pivotal-shell measure.

## 8. Disposition

**Established:** actual Stage 67 collar graph enumerated; two connected components; 125 independent cycle generators; deterministic BFS constants; winding rank 4; exact obstruction to filling collar cycles using only the 65 component-forced-good faces.

**Open:** exact-sector Wilson-loop expectation bounds; concentration around a flat-holonomy moduli; unconditional collar concentration; normalized pivotal-flux suppression; polymer convergence; RG summability; continuum reconstruction; positive physical mass gap.

Stage 69 corrects the gap in the previous cycle-fillability route. It does not establish a Yang–Mills mass gap.
