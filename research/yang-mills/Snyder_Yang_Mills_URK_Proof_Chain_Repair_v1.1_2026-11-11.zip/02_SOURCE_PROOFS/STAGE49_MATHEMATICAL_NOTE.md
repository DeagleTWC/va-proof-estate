# Yang–Mills Mathematical Continuation — Stage 49

**Title:** Global periodic-lattice realization of the one-bad/four-good aligned pivotal star  
**Date:** 2026-11-09  
**Parent:** Stage 48 — local-star obstruction to deterministic angular suppression  
**Project:** Four-dimensional SU(2) Yang–Mills existence and mass gap  
**Disposition:** The Stage 48 local star is now realized by an explicit link assignment on the periodic \(4^4\) lattice. The full link-derived plaquette field satisfies lattice Bianchi identities automatically. The bad component containing the designated neighbour is enumerated exactly, has six plaquettes, and has the target pivotal plaquette as its only threshold face in its closed boundary. A positive coarea-weighted pivotal-surface contribution is then proved for every finite \(\beta>0\), with an explicit but very small lower bound. This does not give a volume-uniform weak-coupling estimate.

## 1. Quaternion and Wilson conventions

Identify \(SU(2)\) with unit quaternions \(q=(q_0,q_1,q_2,q_3)\). For unit quaternions,

\[
\|I-q\|_{\mathrm{op}}=|I-q|_{\mathbb R^4},\qquad
\|I-q\|_{\mathrm{op}}^2=2(1-q_0).
\]

On the periodic lattice \(\Lambda=(\mathbb Z/4\mathbb Z)^4\), let \(U_\mu(x)\in SU(2)\) be the positively oriented link variables and

\[
P_{\mu\nu}(x)=U_\mu(x)U_\nu(x+e_\mu)U_\mu(x+e_\nu)^{-1}U_\nu(x)^{-1},\quad \mu<\nu.
\]

There are \(N_\ell=4\cdot4^4=1024\) links and \(N_p=6\cdot4^4=1536\) plaquettes. The Wilson action convention is

\[
S_W(U)=\beta\sum_{x,\mu<\nu}\left(1-\tfrac12\operatorname{Tr}P_{\mu\nu}(x)\right)
=\beta\sum_p(1-\operatorname{Sc}(P_p)).
\]

A plaquette is strictly bad when \(\|I-P_p\|_{\mathrm{op}}>\delta\).

## 2. Theorem 49.1 — Explicit global link assignment

Set

\[
n=(3/5,4/5,0,0),\qquad n^{-1}=(3/5,-4/5,0,0),
\qquad \delta=\sqrt{2(1-3/5)}=2/\sqrt5.
\]

Let \(0=(0,0,0,0)\), and use coordinate directions \(1,2,3,4\). Assign exactly two non-identity links:

\[
\boxed{U_2(e_1)=n^{-1},\qquad U_1(-e_2)=-n,}
\]

with every other link equal to the identity quaternion.

Let the target link be \(\ell=(0,1)\), so \(U_1(0)=I\). For the six plaquettes incident to \(\ell\), use based orientations beginning with the target link. Their cofactor quaternions are

\[
q_{+2}=n,\quad q_{-2}=-n,\quad
q_{+3}=q_{-3}=q_{+4}=q_{-4}=I.
\]

Thus the target plaquette is exactly pivotal, the negative-2 neighbour is strictly bad, and the other four neighbours are strictly good. The local staple is

\[
\boxed{S=\sum_{j=1}^6q_j=n-n+4I=4I,}
\]

so its direction is exactly the target-link direction. The local angular obstruction from Stage 48 is therefore realized by actual periodic link variables, not by freely assigned plaquette variables.

### Proof

For the positive-2 plaquette,

\[
P_{12}(0)=U_1(0)U_2(e_1)U_1(e_2)^{-1}U_2(0)^{-1}=n^{-1}.
\]

For the negative-2 plaquette, the standard positively oriented plaquette is

\[
P_{12}(-e_2)=U_1(-e_2)U_2(e_1-e_2)U_1(0)^{-1}U_2(-e_2)^{-1}=-n.
\]

Its based orientation starting with \(U_1(0)\) is the inverse, giving cofactor \(q_{-2}=-n\). The other four incident plaquettes have identity holonomy. Since \(n_0=3/5\), their squared defects are respectively \(4/5\), \(16/5\), and \(0\). The staple identity follows by addition. \(\square\)

## 3. Theorem 49.2 — Exact global component and boundary

Construct every plaquette from the link assignment above; do not prescribe plaquette variables independently. Let adjacency mean sharing a link. Let \(p_* = P_{12}(0)\) be the pivotal target plaquette and let \(p_- = P_{12}(-e_2)\) be the designated bad neighbour.

The bad component containing \(p_-\) is exactly

\[
\begin{aligned}
\Gamma=\{&P_{12}(0,2,0,0),\ P_{12}(0,3,0,0),\ P_{13}(0,3,0,0),\\
&P_{14}(0,3,0,0),\ P_{14}(0,3,0,3),\ P_{13}(0,3,3,0)\}.
\end{aligned}
\]

Every member has scalar part \(-3/5\), hence squared defect \(16/5>4/5=\delta^2\). The component has six plaquettes. Its link-sharing boundary has 66 plaquettes; 65 have identity holonomy and the remaining one is exactly \(p_*=P_{12}(0)\), on the threshold. In particular,

\[
\boxed{p_*\in\partial_P\Gamma,\quad
\Gamma\text{ is exactly a connected bad component,}\quad
\partial_P\Gamma\setminus\{p_*\}\text{ is strictly good}.}
\]

There are five additional plaquettes elsewhere with scalar part \(3/5\), but none belongs to \(\Gamma\cup\partial_P\Gamma\); they do not enter the exact-component indicator for \(\Gamma\). All remaining 1524 plaquettes are identity except the 12 non-identity plaquettes just described (six scalar \(-3/5\), six scalar \(+3/5\)).

### Bianchi compatibility

All plaquette holonomies in this construction are computed as ordered products of link variables. Therefore the non-Abelian lattice Bianchi identities hold identically: around every elementary cube, the six parallel-transported face holonomies reduce to cancellation of each oriented edge with its inverse. This construction does not attempt to assign plaquette matrices independently, so there is no untested plaquette-level compatibility assumption.

## 4. Theorem 49.3 — Exact Wilson action

There are six plaquettes with scalar part \(-3/5\), six with scalar part \(+3/5\), and all others have scalar part \(1\). Therefore

\[
\begin{aligned}
S_W(U^*)/\beta
&=6(1+3/5)+6(1-3/5)\\
&=6\cdot 8/5+6\cdot2/5=12.
\end{aligned}
\]

Hence

\[
\boxed{S_W(U^*)=12\beta.}
\]

## 5. Theorem 49.4 — Positive pivotal-surface weight at finite volume

Let \(f(U)=q_0(b)\cdot U_1(0)-3/5\), where \(q_0(b)\) is the unit cofactor determined by the other three links of the target plaquette. On \(f=0\),

\[
|\nabla_{S^3}f|=\sqrt{1-(3/5)^2}=4/5.
\]

At \(U^*\), all six plaquettes of \(\Gamma\) are strictly bad and all 65 boundary plaquettes other than \(p_*\) are strictly good. These are strict inequalities. By continuity, there is an open neighbourhood of the other 1023 links and a relatively open cap of the target-link level sphere on which these inequalities persist. Thus the exact-component indicator \(\mathbf1_{E_\Gamma}\) is identically one on a nonempty relatively open patch of the pivotal hypersurface \(f=0\).

The Wilson density \(e^{-S_W}\) is continuous and strictly positive at every finite link configuration. The coarea factor is finite and nonzero because \(|\nabla f|=4/5\). Therefore

\[
\boxed{
\int_{f=0}\mathbf1_{E_\Gamma}(U)\,
\frac{e^{-S_W(U)}}{|\nabla f(U)|}\,d\mathcal H^{3N_\ell-1}(U)>0
\quad\text{for every finite }\beta>0.
}
\]

This is a positive pivotal-surface contribution, not a positive ordinary probability of the codimension-one event \(f=0\) (which is zero under the volume measure).

### Explicit conservative lower bound

Let \(\eta\) be a target-link chordal cap radius and \(\epsilon\) a radius for each of the other links. Choose

\[
\eta=\min\{\delta/10,\ (24\beta)^{-1}\},\qquad
\epsilon=\min\{\delta/1000,\ \eta/1000,\ (12276\beta)^{-1}\}.
\]

For all links in the indicated product neighbourhood and target-link points in the corresponding cap on \(f=0\), the plaquette product telescoping bound gives

\[
|S_W(U)-S_W(U^*)|
\leq\beta\{6(\eta+3\epsilon)+1530(4\epsilon)\}
\leq1.
\]

The normalized SU(2) Haar volume of an operator-norm ball of radius \(\epsilon\) is

\[
h(\epsilon)=\frac{\alpha-\sin\alpha\cos\alpha}{\pi},
\qquad \alpha=2\arcsin(\epsilon/2).
\]

For a target-link slice \(q_0\cdot u=3/5\), the normalized Haar coarea mass of a chordal cap of radius \(\eta\) is \(5\eta^2/(8\pi)\). By choosing the other-link neighbourhood sufficiently small, the cap persists uniformly over it. The full target-shell Haar coarea density is \(8/(5\pi)\), and \(e^{-S_W}\leq1\). It follows that the normalized pivotal-surface probability obeys the finite-volume lower bound

\[
\boxed{
\Pi_{L=4,\beta}(E_\Gamma\mid f=0)
\geq
\frac{25\eta^2}{64}
\,e^{-12\beta-1}\,h(\epsilon)^{1023}>0.
}
\]

The bound is intentionally conservative. It decays rapidly with \(\beta\) and contains a 1023-link neighbourhood factor. It proves positive finite-volume surface weight, not a uniform weak-coupling lower bound and not a failure of the desired upper-tail estimate.

## 6. Verification results

The exact-rational checker exhaustively enumerates all 1536 plaquettes and verifies:

- 1024 link variables, with exactly two non-identity links;
- all six target-star plaquettes and their exact quaternion values;
- 6 strictly bad plaquettes in the component \(\Gamma\);
- component size 6 and boundary size 66;
- no bad plaquette in the boundary;
- the target plaquette is the unique threshold face in \(\partial_P\Gamma\);
- all 65 other boundary plaquettes are identity;
- six scalar \(-3/5\) and six scalar \(+3/5\) plaquettes globally;
- exact action \(12\beta\);
- the local cofactor staple is \(4I\).

The verification is exact over rational quaternions. It validates the finite-lattice construction and graph bookkeeping; it does not numerically integrate the Wilson measure.

## 7. What this establishes and what remains open

**Established:**
- Global periodic \(4^4\) link assignment realizing the Stage 48 local-star mask.
- Plaquette holonomies are generated from links, hence satisfy lattice Bianchi identities.
- Exact bad component and complete boundary classification.
- Exact Wilson action \(12\beta\).
- Positive finite-volume pivotal-surface contribution for the exact component.
- A conservative explicit lower bound on that contribution.

**Not established:**
- Any useful volume-uniform asymptotic estimate for this surface contribution.
- The upper bound on the total normalized pivotal flux required by Stage 46.
- Uniform weak-coupling suppression of all aligned thick-star strata.
- Wilson-measure polymer convergence, RG summability, continuum reconstruction, or a positive physical mass gap.

## 8. Stage 50 target

The next target is the **conditional Wilson weight of the globally realizable aligned component family**. Compare its exact pivotal-surface numerator with the full target-shell normalizer as \(\beta\to\infty\), and then determine whether the construction can be extended to a family of disjoint or weakly interacting local defects with controlled entropy. The finite-volume lower bound here is a required benchmark for that analysis.

**Disposition:** Stage 49 closes the global realizability and positive finite-volume surface-weight questions left open in Stage 48. It does not prove or disprove the Yang–Mills mass gap.
