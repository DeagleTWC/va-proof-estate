# Yang–Mills Mathematical Continuation — Stage 73

**Title:** Exact separator covariance identities, a sharp SU(2) conditional-mean obstruction, and a necessary weak-coupling criterion  
**Date:** 10 November 2026  
**Parent:** Stage 72, preserved byte-for-byte in `PARENT_STAGE72.zip`  
**Disposition:** Theorems 73.1–73.4 below are finite-dimensional mathematical results. No volume-uniform Wilson covariance decay, exact-sector concentration, or positive continuum mass gap is established.

## 1. Inherited mathematical objects

Retain the Stage 72 exact six-plaquette event on the periodic $(\mathbb Z/4\mathbb Z)^4$ lattice, the 237-link exterior graph, its 125 SU(2) chords, 519 chord-dependent ambient plaquettes, and 380 residual mediator links. For chord tuple $W$,

$$R(W)=\int e^{\beta H_J(W,Y)}\,d\eta_{\Gamma,c}(Y),\quad d\mu_W=R(W)^{-1}e^{\beta H_J(W,Y)}d\eta_{\Gamma,c}(Y).$$

All assertions requiring $\mu_W$ assume $0<R(W)<\infty$. Stage 72 gives for distinct chord geodesic directions $s,t$:

$$\partial_s\partial_t\log R=\beta\mathbb E_W H_{st}+\beta^2\operatorname{Cov}_W(H_s,H_t).\tag{73.1}$$

The issue is the covariance under the *actual constrained Wilson measure*, not the existence of paths in the mediator incidence graph.

## 2. Theorem 73.1 — Exact separator identity, without a spurious independence inference

For any sub-sigma-algebra $\mathscr F$ of the integrated variables, square-integrable $A,B$ satisfy

$$\operatorname{Cov}(A,B)=\mathbb E[\operatorname{Cov}(A,B\mid\mathscr F)]+\operatorname{Cov}(\mathbb E[A\mid\mathscr F],\mathbb E[B\mid\mathscr F]).\tag{73.2}$$

**Proof.** Expand $\mathbb E[AB]-\mathbb EA\mathbb EB$, insert $\mathbb E[AB\mid\mathscr F]$, and add/subtract $\mathbb E[\mathbb E(A\mid\mathscr F)\mathbb E(B\mid\mathscr F)]$. No conditional independence is assumed. If $A,B$ are conditionally independent given $\mathscr F$, the first term vanishes, but the second generally does not. $\square$

## 3. Theorem 73.2 — A rigorous two-term separator bound

Let $A,B$ be bounded real random variables, $a=\mathbb E[A\mid\mathscr F]$, $b=\mathbb E[B\mid\mathscr F]$. Then

$$|\operatorname{Cov}(A,B)|\le \mathbb E\sqrt{\operatorname{Var}(A\mid\mathscr F)\operatorname{Var}(B\mid\mathscr F)}+\sqrt{\operatorname{Var}(a)\operatorname{Var}(b)}.\tag{73.3}$$

If the essential ranges of $a,b$ have lengths $\delta_A,\delta_B$, respectively, then

$$|\operatorname{Cov}(A,B)|\le \mathbb E\sqrt{\operatorname{Var}(A\mid\mathscr F)\operatorname{Var}(B\mid\mathscr F)}+\delta_A\delta_B/4.\tag{73.4}$$

**Proof.** Apply conditional Cauchy–Schwarz to the first term in (73.2), ordinary Cauchy–Schwarz to the second, and Popoviciu's variance bound $\operatorname{Var}(X)\le(\operatorname{esssup}X-\operatorname{essinf}X)^2/4$. $\square$

For $A=H_s,B=H_t$, $|A|,|B|\le6$, the trivial estimate recovers $|\operatorname{Cov}(A,B)|\le36$. A useful Wilson-specific improvement must bound **both** terms in (73.3); selecting a separator alone does not provide decay.

## 4. Theorem 73.3 — Exact SU(2) negative control survives separator conditioning

Use the Stage 72 SU(2) shared-link model

$$H(s,t;U)=\operatorname{Sc}(Ue^{is\sigma_3})+\operatorname{Sc}(U^{-1}e^{it\sigma_3}),\qquad d\mu_0(U)\propto e^{2\beta q_0(U)}dU.$$

Write $U=q_0 I+i\sum_{k=1}^3q_k\sigma_k$ with $q_0^2+\cdots+q_3^2=1$. At $s=t=0$, with consistent orientation of the two traces, $H_s=-q_3$ and $H_t=q_3$; therefore

$$\operatorname{Cov}_{\mu_0}(H_s,H_t)=-\mathbb E_{\mu_0}q_3^2=-\frac{I_2(2\beta)}{2\beta I_1(2\beta)}.\tag{73.5}$$

Take the separator $\mathscr F=\sigma(U)$. Then $H_s,H_t$ are $\mathscr F$-measurable, so

$$\mathbb E[\operatorname{Cov}(H_s,H_t\mid\mathscr F)]=0,\quad \operatorname{Cov}(\mathbb E[H_s\mid\mathscr F],\mathbb E[H_t\mid\mathscr F])=-\frac{I_2(2\beta)}{2\beta I_1(2\beta)}.\tag{73.6}$$

Consequently, even **perfect elimination of conditional covariance** can leave all the mediated curvature in the conditional-mean term:

$$\partial_s\partial_t\log R\big|_{0}=-\frac\beta2\frac{I_2(2\beta)}{I_1(2\beta)}=-\frac\beta2+\frac34+O(\beta^{-1}).\tag{73.7}$$

**Proof.** The Haar-integrated partition function is $R(s,t)=2I_1(2\beta\cos((s+t)/2))/(2\beta\cos((s+t)/2))$. Twice differentiating at zero yields (73.7); the covariance identity with $H_{st}=0$ gives (73.5). The asymptotic follows from $I_2(x)/I_1(x)=1-3/(2x)+O(x^{-2})$. The conditioning statement is immediate because both derivatives are functions of $U$. $\square$

This is a negative control for a proposed **proof method**, not a counterexample to the Yang–Mills mass gap or a computation under the full pivotal-shell measure.

## 5. Theorem 73.4 — Necessary scaling for the covariance route

For non-direct chord pairs, $H_{st}=0$, so by (73.1)

$$|\partial_s\partial_t\log R|=\beta^2|\operatorname{Cov}_W(H_s,H_t)|.\tag{73.8}$$

Therefore a desired uniform $O(1)$ effective cross-curvature bound as $\beta\to\infty$ **requires** $|\operatorname{Cov}_W(H_s,H_t)|=O(\beta^{-2})$ uniformly in the specified pairs, configurations, sectors, and volumes. A desired $o(1)$ curvature requires $o(\beta^{-2})$. In the shared-link negative control the covariance is asymptotic to $-1/(2\beta)$, so its effective curvature grows linearly. These statements follow algebraically from (73.8); they do **not** assert that the target curvature bound is itself necessary for a mass-gap proof.

## 6. Verified computation and limitations

`verification/verify_stage73.py` checks the parent ZIP integrity and SHA-256, its Stage 72 results and ledger, exact algebraic mediator counts inherited from the parent, and 10 high-precision evaluations of the Bessel covariance/curvature identities and weak-coupling scaling. Theorem 73.1–73.4 are proved analytically above; finite numerical checks are supplementary and do not establish the open probabilistic estimates.

## 7. Next obligation: Stage 74

Construct a gauge-covariant Wilson-admissible separator and bound both conditional fluctuations and fluctuations of conditional means **under the actual exact-component pivotal-shell measure**. Account for the 96 mediators inside $I$, the 284 other residual mediators, the 519 chord-dependent plaquettes, and the full ambient Wilson action. An independent uniform estimate, not merely the separator identity, is needed. Open: mediated covariance decay; exact-sector Wilson-loop concentration; collar-complement probability; unconditional pivotal-flux suppression; polymer convergence/RG summability; continuum reconstruction; positive physical mass gap.
