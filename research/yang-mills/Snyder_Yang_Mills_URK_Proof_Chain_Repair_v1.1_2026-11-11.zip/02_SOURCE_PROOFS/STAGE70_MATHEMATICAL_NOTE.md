# Yang–Mills Mathematical Continuation — Stage 70

**Title:** Exact graph gauge quotient and flat-holonomy obstruction  
**Date:** 10 November 2026  
**Parent:** Stage 69 — exact exterior-graph cycle enumeration and forced-good filling obstruction  
**Project:** Four-dimensional SU(2) Yang–Mills existence and mass gap  
**Disposition:** Stage 70 completes the finite-graph gauge quotient for the Stage 67 exterior graph and audits the induced 2-complex. The graph has no plaquette 2-cells whose four edges all lie in the exterior graph. Thus its 125 fundamental-cycle holonomies are independent graph coordinates modulo two residual simultaneous conjugations. The full Wilson measure couples these variables through 696 ambient plaquettes touching the graph, including 450 plaquettes outside the first internal-link shell. No Wilson-loop concentration estimate is proved.

## 1. Inherited finite graph

Use the periodic lattice \(\Lambda=(\mathbb Z/4\mathbb Z)^4\) and the Stage 69 definition of the exterior graph \(G_C=(V_C,C)\). Stage 69's exact enumeration gives

\[
|C|=237,\quad |V_C|=114,\quad c(G_C)=2,
\quad \beta_1(G_C)=237-114+2=125.
\]

Fix the deterministic lexicographic BFS spanning forest \(T\) from Stage 69. It has 112 tree edges and 125 chords \(J=C\setminus T\). The four-dimensional winding map on the cycle space has rank four; its kernel has rank 121 over \(\mathbb Q\).

## 2. Theorem 70.1 — The induced exterior graph has no plaquette 2-cells

Let \(F_C\) be the set of positively oriented ambient lattice plaquettes whose four boundary links all belong to \(C\). Exact enumeration gives

\[
\boxed{|F_C|=0.}
\]

Therefore the 2-complex obtained by taking the graph \(G_C\) and adjoining every ambient plaquette supported entirely in \(C\) is just the graph itself. Its cellular boundary map \(\partial_2:C_2\to C_1\) has rank zero, and

\[
\boxed{H_1(G_C;\mathbb Z)\cong\mathbb Z^{125}.}
\]

In particular, the 121-dimensional rational kernel of the ambient winding map is not killed by plaquette relations internal to \(C\). Such cycles may be null-homologous in the full four-torus, but any filling uses ambient plaquettes not contained entirely in \(C\); Stage 69 established that the 65 component-forced-good faces are disjoint from \(C\).

### Proof

Enumerate all 1,536 positive plaquettes of \((\mathbb Z/4\mathbb Z)^4\). For each plaquette form its canonical four-link boundary and retain it exactly when that boundary is a subset of \(C\). The resulting set is empty. The graph cycle rank is 125 by Stage 69. Since no 2-cells were adjoined, there are no nonzero cellular 2-boundaries, so the first homology is the graph's cycle group, a free abelian group of rank 125. \(\square\)

## 3. Theorem 70.2 — Complete gauge-equivalence coordinates

Let a graph connection be an assignment \(U_e\in SU(2)\) to each positively oriented edge, with reverse orientation assigned \(U_e^{-1}\). Gauge transformations act at vertices by

\[
U_{xy}\mapsto g_xU_{xy}g_y^{-1}.
\]

Choose one root in each of the two components and fix the lexicographic spanning forest \(T\). A vertex gauge transformation sets every tree-edge variable to the identity. For each chord \(e\in J\), the transformed chord variable is exactly the holonomy \(W_e\) around the corresponding fundamental cycle, based at its component root.

The only remaining gauge transformations are one common conjugation per connected component. Thus the graph-connection quotient is

\[
\boxed{\mathcal A(G_C)/\mathcal G(V_C)
\simeq SU(2)^{125}/SU(2)^2,}
\]

where each factor of \(SU(2)^2\) acts by simultaneous conjugation on all 125 chord holonomies belonging to its corresponding graph component.

This is a quotient description, not a claim that the graph holonomies are independent random variables. For generic tuples, each component's simultaneous-conjugation stabilizer is the center \(\{\pm I\}\); the generic quotient dimension is therefore

\[
3\cdot125-2\cdot3=369.
\]

### Proof

Root each tree and recursively choose vertex gauge values so that each oriented tree edge transforms to the identity. On a chord, the gauge-fixed edge is the ordered product around its unique fundamental cycle. Any gauge transformation preserving all tree-edge identities must be constant on each connected component. Such a residual constant conjugates all chord holonomies in that component simultaneously. Conversely, two graph connections with the same chord tuple up to these two conjugations are related by a vertex gauge transformation, by reversing the tree gauge-fixing construction. \(\square\)

## 4. Theorem 70.3 — Ambient Wilson action coupling audit

Although no plaquette lies entirely in \(C\), the graph variables are not absent from the full Wilson action. Exact enumeration gives:

| Ambient plaquette class | Count |
|---|---:|
| Plaquettes with at least one edge in \(C\) | 696 |
| Of these, also containing an edge in the internal set \(I\) | 246 |
| Containing an edge in \(C\) but no edge in \(I\) | 450 |
| Plaquettes with all four edges in \(C\) | 0 |
| Distinct links outside \(I\cup C\) appearing in plaquettes touching \(C\) | 310 |

Thus the 125 cycle coordinates receive their statistical weight through mixed plaquettes and the next exterior shell. The 65 faces forced good by the exact-component event have all four edges in \(I\) and no edge in \(C\); they do not impose direct plaquette-flatness equations on the 125 chord variables.

If all other links are integrated out, the pushforward of the full finite-volume Wilson measure to the 125 chord holonomies has a density with respect to product Haar measure, expressible as

\[
 d\bar\mu_{L,\beta}(W)
 =\mathcal R_{L,\beta}(W)\prod_{e\in J}dW_e,
\]

where \(\mathcal R_{L,\beta}\) is obtained by integrating all remaining link and tree-gauge variables against the complete Wilson weight. It is invariant under the two simultaneous component conjugations. The formula is an exact disintegration; no factorization of \(\mathcal R\) is asserted.

## 5. Corollary — Why local flatness is insufficient here

The graph itself has no 2-cells, so graph-level gauge equivalence leaves 125 cycle holonomies. The rank-four winding map identifies four independent periodic directions, but it does not turn the remaining 121 zero-winding graph cycles into relations: their fillings are not contained in the graph's 2-skeleton. The 65 component-forced-good faces cannot provide such fillings because they are edge-disjoint from \(C\).

For a genuinely flat connection on the *entire* four-torus, the four global holonomies commute and determine a representation of \(\pi_1(T^4)=\mathbb Z^4\) into \(SU(2)\), modulo conjugation. That full-lattice flat-moduli statement must not be confused with the much larger graph quotient above. The exact-component event at issue does not make the entire lattice flat.

## 6. Stage 68 collar metric remains valid

With the Stage 69 lexicographic forest constants \(K_C=942\), the graph-gauge comparison remains

\[
d_C^{\rm orb}(b,[1])^2\leq Q_C(b)
\leq942\,d_C^{\rm orb}(b,[1])^2,
\]

where \(Q_C\) is the sum of fundamental-loop defects. Stage 70 identifies the exact quotient variables underlying this comparison, but does not estimate their distribution.

## 7. Required next estimate

The unresolved quantity remains the exact-component pivotal-shell expectation

\[
\sup_L\sum_{e\in J}
\mathbb E_{\nu_{\Gamma,3/5}}
\left[\|W_e-I\|_{\rm op}^2\right].
\]

The density \(\mathcal R_{L,\beta}(W)\) contains all 696 plaquette interactions touching \(C\), plus their dependence on the 310 next-shell links. A volume-uniform bound on this induced density or its Wilson-loop moments is not obtained here. It cannot be inferred from the 65 forced-good boundary faces.

## 8. Disposition

**Established:** no ambient plaquette is fully supported on \(C\); cycle group rank 125; graph gauge quotient \(SU(2)^{125}/SU(2)^2\); generic quotient dimension 369; 696 ambient plaquettes touch \(C\); 310 further links enter those plaquettes; exact-component forced-good faces give no direct 2-cell relations on \(C\).

**Open:** uniform concentration of the induced chord-holonomy density under the exact-component pivotal-shell measure; flat-moduli collar transfer; unconditional pivotal-flux suppression; polymer convergence; RG summability; continuum reconstruction; positive physical mass gap.

Stage 70 corrects the interpretation of the collar topology. It does not establish the Yang–Mills mass gap.
