# Yang–Mills Mathematical Continuation — Stage 72

**Title:** Exact mediated-chord incidence, uniform curvature bound, and a shared-SU(2)-link obstruction  
**Date:** 10 November 2026  
**Parent:** Stage 71 — exact chord-dependent Wilson action and induced density  
**Lineage:** Four-dimensional SU(2) Yang–Mills existence and mass gap  
**Disposition:** New finite-graph identities and an explicit SU(2) counterexample to the inference that finite-range *direct* interactions imply decaying *effective* cross derivatives. The Wilson-specific covariance decay, unconditional pivotal-flux suppression, continuum construction, and mass gap remain open.

## 1. Inherited measure and variables

Work on the Stage 69–71 periodic lattice $(\mathbb Z/4\mathbb Z)^4$. The 237-link exterior graph has 112 spanning-forest edges (tree-gauge fixed to identity) and 125 chord links $J$. For a chord tuple $W\in SU(2)^{125}$, Stage 71 defines a nonnegative finite measure $d\eta_{\Gamma,c}(Y)$ independent of $W$ and

$$
H_J(W,Y)=\sum_{p\in P_J}q_p(W,Y),\qquad
R(W)=\int e^{\beta H_J(W,Y)}\,d\eta_{\Gamma,c}(Y),
$$

with $q_p=\frac12\operatorname{ReTr}U_p\in[-1,1]$ and $|P_J|=519$. The measure contains the exact six-plaquette-component indicator, the strict-good boundary conditions, the target pivotal-shell coarea factor, and all other Wilson action terms. No independence of the integrated links is assumed. Positivity of $R$ follows whenever the conditional exact-sector coarea measure is nonzero; derivative statements are restricted to such positive-normalizer configurations.

We retain Stage 71's observation that all exact-component and target-shell constraints are supported on internal links $I$ and hence are independent of the chord variables after the gauge change. This does **not** mean the integrated links $Y$ are independent, nor that the exterior sector measure is a product.

## 2. Theorem 72.1 — Exact one-plaquette mediator graph

For each chord $e\in J$, let $P(e)$ be its six incident ambient plaquettes and define the set of *residual one-plaquette mediators*

$$
M(e)=\bigcup_{p\in P(e)} \bigl(\partial p\setminus C\bigr),
$$

where $C$ is the full exterior graph (tree links are fixed and not counted as integrated variables). Let $M=\bigcup_{e\in J}M(e)$.

Exact integer enumeration from the preserved Stage 69 graph gives:

| Quantity | Exact count |
|---|---:|
| Chords $J$ | 125 |
| Chord-dependent plaquettes $P_J$ | 519 |
| Residual mediator links $M$ | 380 |
| Residual mediators in internal set $I$ | 96 |
| Residual mediators outside $I\cup C$ | 284 |
| Distinct residual mediator links per chord | 11 |
| Total chord–mediator incidences | 1,375 |
| Chord pairs sharing a plaquette | 231 |
| Chord pairs sharing at least one mediator | 1,108 |
| Shared-mediator pairs with no direct common plaquette | 877 |
| Pairs sharing neither a direct plaquette nor a one-step mediator | 6,642 |

The one-step mediator chord-adjacency graph is connected and has maximum degree 24. A detailed, machine-readable ledger of all mediators, chord pairs and multiplicities is bundled.

**Proof.** The canonical link representation of each ambient plaquette is the set of its four positive-axis edges. Enumerate $4^4\binom42=1536$ plaquettes. For each plaquette compute intersections with the preserved exact chord set $J$ and graph edge set $C$. The script reconstructs the above sets and counts using integer arithmetic and exact set operations; it does not use a probabilistic approximation.

**Interpretation.** Shared incidence is a possible *route* for mediated dependence, not a proof that the covariance of any particular pair is nonzero. Conversely, pairs with disjoint one-step mediator sets can remain correlated through longer chains and the $W$-independent part of the Wilson action. Therefore these counts cannot be used as a sparsity theorem for the full Hessian of $\log R$.

## 3. Theorem 72.2 — Local Hessian bound with no decay claim

Let $e\ne f$ be chords and vary them along unit-speed SU(2) geodesics $W_e(s)$ and $W_f(t)$. With the positive, normalized conditional measure

$$
d\mu_W(Y)=\frac{e^{\beta H_J(W,Y)}}{R(W)}\,d\eta_{\Gamma,c}(Y),
$$

differentiation under the compact finite-dimensional integral gives

$$
\boxed{\partial_s\partial_t\log R
=\beta\mathbb E_W[H_{st}]
+\beta^2\operatorname{Cov}_W(H_s,H_t).}
$$

Each chord belongs to six plaquettes, and a unit-speed geodesic derivative of any normalized SU(2) plaquette trace has magnitude at most one. Hence $|H_s|,|H_t|\le6$, and $|\operatorname{Cov}(H_s,H_t)|\le36$ by Cauchy–Schwarz. The exact graph has one plaquette shared by a directly adjacent pair and none otherwise, so

$$
\boxed{|\partial_s\partial_t\log R|\le
\beta\,\mathbf 1_{\{e,f\text{ share a plaquette}\}}+36\beta^2.}
$$

This is a finite-graph, exterior-volume-independent Hessian bound, but it grows with $\beta=4/g^2$ and is not a weak-coupling mixing bound.

## 4. Theorem 72.3 — An exact SU(2) shared-link negative control

Consider one Haar-distributed mediator link $U\in SU(2)$, two independent external variables

$$
W_1(s)=e^{is\sigma_3},\qquad W_2(t)=e^{it\sigma_3},
$$

and the two-plaquette-type action

$$
H(s,t;U)=\operatorname{Sc}(UW_1(s))
+\operatorname{Sc}(U^{-1}W_2(t)).
$$

Here $\operatorname{Sc}(Q)=\tfrac12\operatorname{ReTr}(Q)$. For every fixed $U$,

$$
\partial_s\partial_t H(s,t;U)=0,
$$

because the first term depends only on $s$ and the second only on $t$.

Using $\operatorname{Sc}(U^{-1}W_2)=\operatorname{Sc}(UW_2^{-1})$ and the quaternion length $|W_1(s)+W_2(t)^{-1}|=2|\cos((s+t)/2)|$, the exact Haar integral, near $(s,t)=(0,0)$, is

$$
R_\beta(s,t)=\int_{SU(2)} e^{\beta H(s,t;U)}\,dU
=Z\bigl(2\beta\cos((s+t)/2)\bigr),
\quad Z(k)=\frac{2I_1(k)}{k}.
$$

Since $Z'(k)/Z(k)=I_2(k)/I_1(k)$, the mixed derivative is

$$
\boxed{\left.\partial_s\partial_t\log R_\beta(s,t)\right|_{0}
=-\frac\beta2\frac{I_2(2\beta)}{I_1(2\beta)}
=-\frac\beta2+O(1).}
$$

Equivalently, the entire mixed derivative comes from the conditional covariance term:

$$
\operatorname{Cov}_{\mu_0}(H_s,H_t)
=-\mathbb E_{\mu_0}[q_3(U)^2]
=-\frac{1}{2\beta}\frac{I_2(2\beta)}{I_1(2\beta)}.
$$

Thus this completely explicit SU(2) motif has **zero direct mixed action derivative but effective mixed log-partition curvature of order $\beta$**. This is a counterexample to *deducing effective curvature decay solely from zero direct incidence*, not a counterexample to Yang–Mills mass-gap existence and not an assertion about the exact-component conditional Wilson measure on the full lattice.

## 5. Theorem 72.4 — Conditional covariance decomposition

For any sigma-algebra $\mathscr F$ of the integrated-variable probability space,

$$
\operatorname{Cov}_{\mu_W}(H_s,H_t)
=\mathbb E_W[\operatorname{Cov}(H_s,H_t\mid\mathscr F)]
+\operatorname{Cov}_W(\mathbb E[H_s\mid\mathscr F],\mathbb E[H_t\mid\mathscr F]).
$$

This identity separates covariation remaining after conditioning from correlations of the conditional means. Selecting a useful Wilson-admissible separator $\mathscr F$ and bounding the two terms is a possible next proof route; no independence or smallness is inferred here.

## 6. Exact checks and reproducibility

The package's Python verifier reads the unmodified Stage 71 ZIP and its nested Stage 70/69 exact graph data, recomputes the 519-plaquette incidence table and the 380 residual mediators, and writes a full 643-KB mediator ledger. For the SU(2) motif it compares the exact Bessel expression with automatic high-precision mixed differentiation at eight couplings and checks the quaternion trace identity on 2,000 seeded samples.

**Result: 2,029 assertions passed.** The exact graph assertions are integer/set-theoretic; the SU(2) sampled tests are supplementary. The mathematical proof does not rely on their sample count.

## 7. Stage 73 target and open obligations

The next legitimate mathematical target is to bound the *conditional* covariance for the actual four-dimensional Wilson measure on the selected exact-component pivotal shell. A viable route would quantify the influence along integrated-link chains after gauge-mode treatment, with estimates that remain useful as $\beta\to\infty$. The current bound $36\beta^2$ and the SU(2) shared-link counterexample show why direct graph degree and ordinary finite range are insufficient.

**Open:** uniform mediated covariance decay; exact-sector Wilson-loop concentration; collar-complement probability; unconditional pivotal-flux suppression; polymer convergence and RG summability; continuum reconstruction; positive physical Yang–Mills mass gap.

This is a mathematical continuation, not a tool-package milestone. Previous stages and protected kernels are left unchanged; no public repository or site changes have been made.
