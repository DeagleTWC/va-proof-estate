# Yang–Mills Mathematical Continuation — Stage 54

**Title:** Variance-controlled transfer from the reference exterior law to the shell-size-biased exterior law  
**Date:** 9 November 2026  
**Parent:** Stage 53 — exact exterior-size-biased pivotal-sector disintegration  
**Project:** Four-dimensional SU(2) Yang–Mills existence and mass gap  
**Disposition:** Stage 54 proves exact identities and conditional transfer inequalities. It does not prove the required Wilson-specific variance or rare-sector estimate.

## 1. Parent setup

Fix a finite periodic four-dimensional lattice and a target plaquette shell with scalar value \(c\in(-1,1)\). In the Stage 53 notation, let \(b\) denote exterior links and let

\[
A_b(c)=\int e^{\beta Y_b(U_B)}\,d\sigma_c(U_B),\qquad
A_{\Gamma,b}(c)=\int e^{\beta Y_b(U_B)}\chi_\Gamma(U_B,b;c)\,d\sigma_c(U_B).
\]

Here \(\sigma_c\) is the normalized Haar fibre measure on the four-link block at fixed target holonomy scalar, \(Y_b\) retains all four crossing-staple interactions, and \(0\leq\chi_\Gamma\leq1\) is the exact pivotal-component indicator. Define

\[
p_\Gamma(b,c)=\frac{A_{\Gamma,b}(c)}{A_b(c)}\in[0,1],\qquad
a(c)=\mathbb E_0 A_b(c),
\]

where \(\mathbb E_0\) denotes the reference exterior expectation from Stage 53. The shell-size-biased exterior measure is

\[
d\nu_c(b)=\frac{A_b(c)}{a(c)}d\mu_0(b).
\]

The exact sector probability is

\[
\Pi_\Gamma(c)=\mathbb E_{\nu_c}p_\Gamma(\cdot,c)
=\frac{\mathbb E_0[A_b(c)p_\Gamma(b,c)]}{a(c)}.
\tag{54.1}
\]

Stage 53 established the fibrewise bounds \(1\leq A_b(c)\leq M_\beta\), with \(M_\beta=Z(20\beta)\), for the stated Wilson normalization. Stage 54 does not repeat the derivation of that bound; it uses only positivity and square-integrability of \(A_b(c)\).

## 2. Theorem 54.1 — Exact covariance correction

Let

\[
m_\Gamma(c)=\mathbb E_0 p_\Gamma(\cdot,c),\qquad
v_A(c)=\operatorname{Var}_0(A_b(c)).
\]

Then

\[
\boxed{
\Pi_\Gamma(c)-m_\Gamma(c)
=\frac{\operatorname{Cov}_0(A_b(c),p_\Gamma(\cdot,c))}{a(c)}.
}
\tag{54.2}
\]

In particular,

\[
\boxed{
\left|\Pi_\Gamma(c)-m_\Gamma(c)\right|
\leq\frac{\sqrt{v_A(c)\operatorname{Var}_0(p_\Gamma)}}{a(c)}
\leq\frac{\sqrt{v_A(c)m_\Gamma(c)(1-m_\Gamma(c))}}{a(c)}.
}
\tag{54.3}
\]

Consequently,

\[
\boxed{
\Pi_\Gamma(c)
\leq m_\Gamma(c)+
\frac{\sqrt{v_A(c)m_\Gamma(c)(1-m_\Gamma(c))}}{a(c)}.
}
\tag{54.4}
\]

The lower companion is the positive part of the corresponding difference bound.

### Proof

From (54.1),
\[
\Pi_\Gamma-m_\Gamma
=\frac{\mathbb E_0[A p]-a\mathbb E_0p}{a}
=\frac{\operatorname{Cov}_0(A,p)}{a}.
\]
Cauchy–Schwarz gives \(|\operatorname{Cov}(A,p)|\leq\sqrt{\operatorname{Var}(A)\operatorname{Var}(p)}\). Since \(0\leq p\leq1\), \(p^2\leq p\), so
\[
\operatorname{Var}(p)=\mathbb E p^2-(\mathbb E p)^2
\leq m_\Gamma-m_\Gamma^2.
\]
Substitution proves (54.3) and (54.4). \(\square\)

## 3. Theorem 54.2 — Chi-square and total-variation control of the size bias

The Radon–Nikodym derivative is \(w=A/a\). Therefore

\[
\boxed{
\chi^2(\nu_c\|\mu_0)
=\mathbb E_0[(w-1)^2]
=\frac{v_A(c)}{a(c)^2}.
}
\tag{54.5}
\]

It follows that

\[
\boxed{
\|\nu_c-\mu_0\|_{\rm TV}
\leq\frac12\sqrt{\chi^2(\nu_c\|\mu_0)}
=\frac{\sqrt{v_A(c)}}{2a(c)}.
}
\tag{54.6}
\]

For any measurable \(F\) with \(0\leq F\leq1\),
\[
|\mathbb E_{\nu_c}F-\mathbb E_0F|
\leq\frac{\sqrt{v_A(c)}}{2a(c)}.
\tag{54.7}
\]

This is a more informative transfer condition than the Stage 53 worst-case likelihood-ratio bound when \(A_b(c)\) is concentrated under \(\mu_0\). It is not automatically stronger: without a variance estimate, the range bound may be all that is available.

## 4. Theorem 54.3 — Exact two-replica representation

Let \(U,V\) be independent samples from the same fixed-holonomy fibre measure \(\sigma_c\), conditionally independent given the exterior \(b\). Then

\[
A_b(c)^2
=\mathbb E_{\sigma_c\otimes\sigma_c}
\exp\{\beta Y_b(U)+\beta Y_b(V)\}.
\]

Hence

\[
\boxed{
\mathbb E_0[A_b(c)^2]
=\mathbb E_{\mu_0\otimes\sigma_c\otimes\sigma_c}
\exp\{\beta Y_b(U)+\beta Y_b(V)\},
}
\tag{54.8}
\]

and

\[
\boxed{
v_A(c)=
\mathbb E_{0,\sigma_c\otimes\sigma_c}
 e^{\beta(Y_b(U)+Y_b(V))}
-\left(\mathbb E_{0,\sigma_c}e^{\beta Y_b(U)}\right)^2.
}
\tag{54.9}
\]

The two replicas share the same exterior links. Thus (54.9) isolates the exterior-induced correlation of the two block partition factors. It does not assume independence after averaging over \(b\).

## 5. Corollary 54.4 — Uniform transfer criterion

Consider a family of lattices and couplings indexed by \((L,g)\). Write \(m_{L,g}=\mathbb E_0p_\Gamma\), \(a_{L,g}=\mathbb E_0A\), and \(v_{L,g}=\operatorname{Var}_0(A)\). Since Stage 53 gives \(A\geq1\), we have \(a_{L,g}\geq1\). Therefore, if

\[
\boxed{
\sup_L m_{L,g}\longrightarrow0,
\qquad
\sup_L v_{L,g}m_{L,g}\longrightarrow0
\quad(g\downarrow0),
}
\tag{54.10}
\]

then

\[
\boxed{\sup_L\Pi_{\Gamma,L,g}(c)\longrightarrow0.}
\tag{54.11}
\]

This is a sufficient condition, not a conclusion about the Wilson measure. It identifies a joint rare-sector/size-bias-variance estimate that would transfer reference-exterior decay to the correct shell-conditioned exterior law.

## 6. Range-only fallback and its limitation

If only \(1\leq A\leq M_\beta\) is known, Popoviciu's inequality gives
\[
v_A\leq\frac{(M_\beta-1)^2}{4}.
\]
Then (54.4) yields the valid but potentially crude estimate
\[
\Pi_\Gamma\leq m_\Gamma+
\frac{M_\beta-1}{2a}\sqrt{m_\Gamma(1-m_\Gamma)}.
\]
Since \(M_\beta=Z(20\beta)\) grows rapidly at large \(\beta\), this fallback does not close the weak-coupling problem. The point of Stage 54 is to make \(v_A\), rather than the full range of \(A\), the explicit quantity to estimate.

## 7. Exact two-state counterexample

Let the reference exterior space have two equally likely points. Set \(A(0)=1\), \(A(1)=M\), and let \(p(0)=0\), \(p(1)=1\). Then
\[
m=\frac12,\quad a=\frac{1+M}{2},\quad v_A=\frac{(M-1)^2}{4},\quad
\Pi=\frac{M}{1+M}.
\]
Thus \(\Pi\to1\) as \(M\to\infty\), although \(m=1/2\). More generally, by taking \(p\) supported on the high-weight exterior point and its reference mass small, one sees why an ordinary-measure rare-event estimate alone does not control the size-biased expectation when the weight variance is uncontrolled. This is an algebraic counterexample to a measure-transfer shortcut, not a counterexample to the Wilson measure.

## 8. Disposition and next mathematical target

**Established:** exact covariance correction; Cauchy–Schwarz rare-sector bound; chi-square/TV identity for the shell size bias; exact two-replica formula for \(\operatorname{Var}_0 A_b(c)\); sufficient uniform transfer criterion.

**Open:** a Wilson-specific upper bound on the shared-exterior two-replica fluctuation (54.9) that is uniform in lattice volume and useful as \(g\downarrow0\); a matching estimate on \(m_{L,g}\); normalized pivotal-flux decay; polymer convergence; RG summability; continuum reconstruction; positive physical mass gap.

**Stage 55 target:** estimate the two-replica exterior covariance in (54.9), exploiting the finite range and gauge structure of the four-link crossing interaction while keeping the two block replicas coupled through the same exterior. Do not replace the shared exterior by independent copies.
