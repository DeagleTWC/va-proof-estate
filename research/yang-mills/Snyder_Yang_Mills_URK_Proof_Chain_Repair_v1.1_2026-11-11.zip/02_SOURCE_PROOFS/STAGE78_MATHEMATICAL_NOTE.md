# Yang–Mills — Stage 78: Internal-sector isolation and conditional exterior-mediator topology
Date: 2026-11-10. Parent: complete unchanged Stage 77 archive. Stage 72 source separately retained for exact-count provenance.

## Inherited setting
Work on the periodic 4^4 SU(2) lattice and the Stage 72 disintegration R(W)=∫exp(β H_J(W,Y))η_{Γ,c}(dY). The exact-component indicator, strict-good conditions and pivotal-shell coarea factor are supported on internal links I; the 125 chord variables W are external. Stage 72's mediator ledger contains 380 residual links, of which 96 belong to I and 284 belong outside I∪C. The remaining integrated links not in the mediator ledger are also part of Y. We make no assumption that η factorizes across its internal variables.

## Theorem 78.1 — Exact mediator partition
Let M denote the 380 distinct residual mediator links. The disjoint partition M=(M∩I) ⊔ (M\(I∪C)) has sizes 96 and 284. This follows directly from the inherited exact link-set enumeration, not a probability estimate. The full set of internal links contains 120 links; the 96 are only the internal links which are also residual chord mediators.

## Theorem 78.2 — Connected conditional exterior-mediator sections
Let X denote the 284 integrated links in M\(I∪C). Let Z collect all other integrated links and the chord variables. Assume the exact-component event and coarea measure depend only on the internal coordinates included in Z, and that for the chosen admissible Z the conditional law in X is proportional to exp(β S(X,Z)) product Haar dX, with finite real Wilson action S and positive normalizer. Then the conditional density is everywhere strictly positive on SU(2)^284. Therefore its topological support is the connected product group SU(2)^284. The hard exact-sector constraints cannot disconnect these conditional X sections. Proof: each Wilson plaquette term is continuous and bounded; finite β gives a positive continuous density; the product SU(2)^284 is path connected.

Caution: fixing all other integrated links is essential. The theorem does not imply that the entire Y support is connected or that the marginal in X is uniformly mixing. The coarea factor can be singular in the internal variables without invalidating the conditional X conclusion where disintegration exists.

## Theorem 78.3 — Finite-coupling conditional Poincare comparison
At fixed admissible Z, let N_X be the number of distinct plaquettes with at least one link in X. Since each of the 284 links meets six elementary plaquettes in the four-dimensional lattice, N_X≤6·284=1704. For the normalized Wilson action q_p∈[-1,1], osc_X S≤2N_X≤3408. With the round S^3 metric on each SU(2), Haar product has spectral gap 3. Thus, for smooth real f,

Var(f|Z) ≤ (exp(3408 β)/3) E[||∇_X f||²|Z], β≥0.

This is a rigorous but very weak bound; it is uniform in admissible fixed Z and in extensions preserving the same local X incidence, but not in β. It cannot establish weak-coupling mixing.

## Theorem 78.4 — Two-level covariance obstruction persists
For observables A,B depending on X,Z, Cov(A,B)=E[Cov(A,B|Z)]+Cov(E[A|Z],E[B|Z]). Theorem 78.3 bounds only the first contribution (under gradient hypotheses). The second is governed by the internal constrained sector and its induced marginal. In particular, path connectedness of the X sections does not imply a spectral gap for the internal pivotal-shell measure.

## Proposition 78.5 — Exact residual topology target
The remaining topology problem can be restricted to the constrained internal-coordinate support and its coarea regularity, with 96 chord-mediating internal links and 24 other internal links among the inherited 120 internal links. However, the other integrated variables can mediate coupling and cannot be discarded from probability estimates. Counts alone do not identify the number of connected components, regularity of shell level sets, or a Cheeger constant. A proof must use the explicit shell defining map and its regular-value conditions from the Stage 67/71 ancestry.

## Disposition
Established: exact 96+284 mediator partition; conditional connected full-support exterior sections; explicit finite-β conditional Poincare comparison; exact residual two-level covariance obligation. Open: internal pivotal-shell fiber topology; uniform β and volume bounds; conditional-mean covariance; pivotal flux suppression; polymer/RG convergence; continuum reconstruction; positive physical mass gap. Theorems 78.2–78.4 are mathematical deductions under stated disintegration assumptions, not independently machine-certified proofs. The verifier checks inherited structural quantities and archive integrity only.
