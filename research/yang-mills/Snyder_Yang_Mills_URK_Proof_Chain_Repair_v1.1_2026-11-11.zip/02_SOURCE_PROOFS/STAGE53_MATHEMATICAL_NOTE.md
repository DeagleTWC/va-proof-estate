# Yang--Mills Mathematical Continuation — Stage 53

**Title:** Exact exterior-size-biased disintegration of the pivotal component sector  
**Date:** 9 November 2026  
**Parent:** Stage 52 — fixed four-link conditional shell integral  
**Project:** Four-dimensional SU(2) Yang--Mills existence and mass gap  
**Disposition:** Stage 53 derives the exact exterior marginal on a target-plaquette shell and the exact conditional probability of a specified pivotal component sector. It identifies the correct exterior size-biasing factor. It does not establish the missing weak-coupling estimate.

## 1. Setup inherited from Stage 52

Fix a finite periodic four-dimensional lattice, a target plaquette \(p_*\), and its four-link boundary block \(B\). Write \(b\) for all exterior links and \(U_B\in SU(2)^4\) for the block links. On the fibre where the scalar part of the target holonomy is \(f(U_B)=c\), Stage 52 decomposes the Wilson weight as

\[
 e^{-S_W(U_B,b)}=e^{-S_{\rm ext}(b)}e^{-20\beta}e^{-\beta(1-c)}e^{\beta Y_b(U_B)},
\]

where \(S_{\rm ext}\) contains plaquettes disjoint from \(B\), and \(Y_b\) is the sum of the four quaternionic crossing-staple pairings. Let \(\sigma_c\) be the conditional product-Haar fibre probability at target scalar \(c\), and define

\[
 A_b(c)=\int e^{\beta Y_b(U_B)}\,d\sigma_c(U_B).
\]

For a measurable pivotal-sector indicator \(\chi_\Gamma(U_B,b;c)\in[0,1]\), with the chosen one-sided trace convention on the target threshold surface, define the sector-restricted fibre factor

\[
 A_{\Gamma,b}(c)=\int e^{\beta Y_b(U_B)}\chi_\Gamma(U_B,b;c)\,d\sigma_c(U_B).
\]

The indicator may encode the complete connected-component constraints, including all plaquettes in the component and its boundary. No factorization of those constraints is assumed.

Set

\[
 Z_{\rm ext}=\int e^{-S_{\rm ext}(b)}\,db,
 \qquad d\mu_{\rm ext}^0(b)=Z_{\rm ext}^{-1}e^{-S_{\rm ext}(b)}db.
\]

The measure \(\mu_{\rm ext}^0\) is a reference exterior measure: it contains only plaquette interactions disjoint from the four-link block.

## 2. Theorem 53.1 — Exact shell disintegration

For every regular target scalar \(c\in(-1,1)\), the full Wilson shell density is

\[
 \mathcal D_{L,\beta}(c)=
 \frac{h(c)e^{-20\beta}e^{-\beta(1-c)}Z_{\rm ext}}{Z_{L,\beta}}
 \mathbb E_{\mu_{\rm ext}^0}[A_b(c)],
 \tag{53.1}
\]

where \(h(c)=2\sqrt{1-c^2}/\pi\). The pivotal-sector shell density is

\[
 \mathcal D_{\Gamma,L,\beta}(c)=
 \frac{h(c)e^{-20\beta}e^{-\beta(1-c)}Z_{\rm ext}}{Z_{L,\beta}}
 \mathbb E_{\mu_{\rm ext}^0}[A_{\Gamma,b}(c)].
 \tag{53.2}
\]

Hence the exact conditional pivotal-sector probability on the shell is

\[
 \boxed{
 \Pi_{\Gamma,L,\beta}(c)=
 \frac{\mathbb E_{\mu_{\rm ext}^0}[A_{\Gamma,b}(c)]}
 {\mathbb E_{\mu_{\rm ext}^0}[A_b(c)]}.
 }
 \tag{53.3}
\]

### Proof

Apply the Haar disintegration of the four target links with respect to the scalar \(c\). The target Haar density contributes \(h(c)dc\). The block/exterior decomposition of the Wilson action contributes the four factors displayed above. Integrating first over the fibre gives \(A_b(c)\) for the unrestricted shell and \(A_{\Gamma,b}(c)\) when the pivotal-sector indicator is inserted. Integrating over \(b\) gives (53.1) and (53.2). Their common positive prefactor cancels, proving (53.3). This is an identity for every finite lattice and uses no independence assumption for the crossing plaquettes or for the component constraints. \(\square\)

## 3. Theorem 53.2 — Exterior size-biased representation

Define the shell-conditioned exterior probability measure

\[
 \boxed{
 d\nu_c(b)=
 \frac{A_b(c)}{\mathbb E_{\mu_{\rm ext}^0}A_b(c)}
 d\mu_{\rm ext}^0(b).
 }
 \tag{53.4}
\]

For \(A_b(c)>0\), define the fibre-conditional sector probability

\[
 p_\Gamma(b,c)=\frac{A_{\Gamma,b}(c)}{A_b(c)}\in[0,1].
\]

Then

\[
 \boxed{\Pi_{\Gamma,L,\beta}(c)=\mathbb E_{\nu_c}[p_\Gamma(b,c)].}
 \tag{53.5}
\]

### Proof

Substitute \(A_{\Gamma,b}=A_b p_\Gamma\) into (53.3), then use (53.4). Positivity of the Wilson fibre weight gives \(A_b>0\), and \(0\leq\chi_\Gamma\leq1\) gives \(0\leq p_\Gamma\leq1\). \(\square\)

Equation (53.5) is the central point of this stage: the exterior configurations must be averaged under the shell-conditioned, size-biased measure \(\nu_c\), not under the unweighted reference measure \(\mu_{\rm ext}^0\).

## 4. Theorem 53.3 — Exact comparison bounds

The lower bound is Jensen's inequality and the zero fibre mean of \(Y_b\). For the upper bound, write \(Y_b=\sum_{i=1}^4 X_i\), where \(X_i=\langle U_i,S_i(b)\rangle\). The four \(U_i\) are generally not independent under \(\sigma_c\), so the product factorization from the *unconditioned block integral* in Stage 52 cannot be applied pointwise on a fixed fibre. Instead, generalized Hölder and the Haar marginality of each \(U_i\) give

\[
A_b(c)\leq\prod_{i=1}^4
\left(\mathbb E_{\sigma_c}e^{4\beta X_i}\right)^{1/4}
=\prod_{i=1}^4 Z(4\beta|S_i(b)|)^{1/4}
\leq Z(20\beta),
\]

where \(Z(t)=2I_1(t)/t\), \(Z(0)=1\), and \(Z\) is nondecreasing. Thus the corrected, fibrewise bound is

\[
\boxed{1\leq A_b(c)\leq Z(20\beta).}
\tag{53.6}
\]

This Hölder step does not assume independence among the four links. It is the pointwise fibre estimate needed for the exterior comparison.

Consequently, for every exterior-measurable \(0\leq F\leq1\),

\[
 \boxed{
 \frac{\mathbb E_0 F}{Z(20\beta)}
 \leq \mathbb E_{\nu_c}F
 \leq Z(20\beta)\mathbb E_0F,
 }
 \tag{53.7}
\]

where \(\mathbb E_0\) abbreviates \(\mathbb E_{\mu_{\rm ext}^0}\). In particular,

\[
 \Pi_{\Gamma,L,\beta}(c)
 \leq Z(20\beta)\mathbb E_0[p_\Gamma(\cdot,c)].
 \tag{53.8}
\]

Also, the Radon--Nikodym derivative is exactly

\[
 \frac{d\nu_c}{d\mu_{\rm ext}^0}(b)=
 \frac{A_b(c)}{\mathbb E_0 A_b(c)},
 \tag{53.9}
\]

and (53.6) implies the likelihood-ratio range bound

\[
 \frac{\operatorname*{ess\,sup}(d\nu_c/d\mu_{\rm ext}^0)}
 {\operatorname*{ess\,inf}(d\nu_c/d\mu_{\rm ext}^0)}
 \leq Z(20\beta).
 \tag{53.10}
\]

The resulting general total-variation comparison is

\[
 \|\nu_c-\mu_{\rm ext}^0\|_{\rm TV}
 \leq \tanh(\frac14\log Z(20\beta)),
 \tag{53.11}
\]

using the sharp likelihood-ratio bound \(\|q\mu_0-\mu_0\|_{\rm TV}\leq\tanh(\frac14\log R)\) when \(\operatorname*{ess\,sup}q/\operatorname*{ess\,inf}q\leq R\). This comparison becomes weak as \(\beta\to\infty\), because \(Z(20\beta)\) grows exponentially.

### Proof of (53.7)

From (53.6), \(1\leq A_b\leq M\) with \(M=Z(20\beta)\), hence \(1\leq\mathbb E_0A_b\leq M\). Thus

\[
 \frac{1}{M}\leq\frac{A_b}{\mathbb E_0A_b}\leq M.
\]

Integrating a nonnegative \(F\) against this density proves (53.7). The likelihood ratio in (53.9) has essential supremum/infimum at most \(M\), so (53.11) follows from the stated sharp comparison inequality. \(\square\)

### Fibrewise-normalization correction to the Stage 52 comparison

The Stage 52 product estimate bounds the *integrated block partition function* after dropping the target factor. It does not, by itself, imply a pointwise upper bound on \(A_b(c)\), because the four target links are correlated on the fixed-product fibre. Stage 53 supplies the valid fibrewise upper bound through Hölder. This distinction is retained in the proof and in the corrected comparison factor \(Z(20\beta)\).

## 5. Normalization counterexample: why the exterior size bias cannot be omitted

Take a two-point exterior space \(b\in\{0,1\}\) with \(\mu_0(0)=\mu_0(1)=1/2\), shell factors \(A_0=1\), \(A_1=M\), and sector probabilities \(p_\Gamma(0)=0\), \(p_\Gamma(1)=1\), where \(M>1\). Then

\[
 \mathbb E_{\mu_0}p_\Gamma=\frac12,
 \qquad
 \Pi_\Gamma=\mathbb E_{\nu_c}p_\Gamma=
 \frac{e^\beta}{1+e^\beta}\longrightarrow1.
\]

Thus replacing the correct shell-conditioned exterior expectation by the unweighted reference expectation can give an order-one error, even in a two-state model. This is an algebraic counterexample to that substitution, not a counterexample to the Wilson measure.

## 6. Consequence for Stage 50 and the next estimate

The correct exterior-averaged pivotal-sector quantity is (53.3) or equivalently (53.5). A useful weak-coupling estimate must control \(p_\Gamma(b,c)\) under \(\nu_c\), or jointly control \(A_{\Gamma,b}(c)\) and \(A_b(c)\) under \(\mu_0\). An ordinary-measure bound under \(\mu_0\) transfers only with the factor \(Z(20\beta)\) in (53.8), which is not useful at weak coupling without additional decay.

The finite-block identities themselves are volume-uniform, but no decay in \(\beta\) has been established for the exact-component event. The stage therefore repairs the averaging and normalization logic; it does not close the pivotal-flux estimate.

## 7. Disposition and next mathematical target

**Established:** exact shell/exterior disintegration; correct size-biased exterior law; exact-component probability as a shell-conditioned exterior expectation; finite-volume comparison inequalities; explicit counterexample to unweighted exterior averaging.

**Open:** a Wilson-specific weak-coupling bound on \(\mathbb E_{\nu_c}p_\Gamma\) (or a direct joint bound on \(A_{\Gamma,b}/A_b\)) that is uniform in volume and component geometry; normalized pivotal-flux decay; polymer convergence; RG summability; continuum reconstruction; positive physical mass gap.

**Stage 54 target:** prove a useful estimate on the sector probability \(p_\Gamma(b,c)\) under the *size-biased exterior law* \(\nu_c\), retaining the exact component indicator and all crossing-plaquette interactions. Do not replace \(\nu_c\) by \(\mu_0\) without paying and controlling the likelihood-ratio factor.
